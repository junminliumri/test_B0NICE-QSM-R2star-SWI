function [algoParams] = FatCats_SetAlgoParams4MagFitting(algoParams)
%--------------
%set up default algoParams
% for magnitude fitting
algoParams.FF_trl = [0.0 0.15 0.25 0.5 0.75 0.85 1.0]; 
%algoParams.FF_trl = 0:0.1:1.0;
algoParams.R2star_pt = 0:5:300; % unit: Hz
%algoParams.FFth4magWater = 0.3;
%---------------------------------------------
