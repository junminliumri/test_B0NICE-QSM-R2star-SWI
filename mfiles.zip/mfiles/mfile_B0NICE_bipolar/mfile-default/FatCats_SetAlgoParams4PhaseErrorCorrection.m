function [algoParams] = FatCats_SetAlgoParams4PhaseErrorCorrection(algoParams)
%--------------
%set up default algoParams
% for dividing B0 map into regions
algoParams.th4label = algoParams.error_2pi/2;
algoParams.minAreaUsingPhaseGradient = 20; % used by FatCats_defineRegion_usingPhaseGradient
%---------------------------------------------
%algoParams.minAreaUsingPhaseError = 100; % used by FatCats_BW_labelUsingPhaseError
%
algoParams.minAreaUsingFlip = 100; % used by FatCats_BW_labelUsingFlip