function [algoParams] = FatCats_SetAlgoParams4PUROR(algoParams)
%--------------
%set up default algoParams
%
% for phase unwrapping
algoParams.th4unwrap = 0; 
algoParams.th4supp = 0.0; % 0.0 for phantom; 0.5 for invivo
algoParams.th4STAS = 8.0;
if algoParams.matrix_size(3) < 50
algoParams.unwrap_mode = 2; % 2 for 2D PUROR; 3 for 3D PUROR
else
algoParams.unwrap_mode = 3; % 2 for 2D PUROR; 3 for 3D PUROR    
end
% Note that the above parameters may need be optimized for some specific cases
% for example, ch-by-ch unwrapping related to intensity inhomogeneity
%---------------------------------------------
