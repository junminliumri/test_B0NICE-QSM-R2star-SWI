%
function [algoParams] = FatCats_VerifyInputData(imDataParams)
%
pi_2 = 2*pi;
num_step = 100;
%
B0_strength = imDataParams.FieldStrength; % unit:T
spin_dir = imDataParams.PrecessionIsClockwise;
TE_seq = imDataParams.TE;% unit:s
algoParams.TE_seq = TE_seq;
%
%new model from Henando MRM paper mrm 77:1516-1524, 2017
%CS_water = [-3.90 -3.50 -2.70 -2.04 -0.49 0.50]; % unit in ppm;
%model_f = CS_water.*(4258*B0_strength*1e-2);
%old fat model from 2012 fat-water challenge
model_f = [-242.7060 -217.1580 -166.0620 -123.9078 -24.9093 38.3220];
model_f = model_f.*(B0_strength/1.5);
model_r = [0.0870 0.6930 0.1280 0.0040 0.0390 0.0480];
%
algoParams.model_r = model_r;
algoParams.model_f = model_f;
algoParams.num_step = num_step;
algoParams.B0_strength = B0_strength;
%
%------------------------------
phase_echo = zeros(1,length(TE_seq));
mag_echo = zeros(1,length(TE_seq));
    for index_echo = 1:length(TE_seq)
    TE_tmp = TE_seq(index_echo);
    model_complex = model_r.*exp(1i.*(2*pi*TE_tmp.*model_f));
    model_complex_sum = sum(model_complex);
    phase_echo(index_echo) = angle(model_complex_sum);
    mag_echo(index_echo) = abs(model_complex_sum);
    end
%phase_echo/pi
%close all
%plot(phase_echo/pi,'o-r');
%pause
algoParams.Phase4Echo_ori = phase_echo;
algoParams.Mag4Echo_ori = mag_echo;
%-----------------------------
%
complex_3D = imDataParams.images;
matrix_size = size(complex_3D);
%
complex_image = zeros(matrix_size(1),matrix_size(2),matrix_size(3),1,matrix_size(5));
%
if matrix_size(4) > 1
    for index_slice = 1:matrix_size(3)
    complex_slice(:,:,1,:,:) = complex_3D(:,:,index_slice,:,:);
    [sliceComb] = coilCombine(complex_slice);
    im_tmp(:,:) = sliceComb(:,:,1,1,1);
        if index_slice == matrix_size(3)
        figure(1)
        subplot(1,2,1);imagesc(abs(im_tmp));
        subplot(1,2,2);imagesc(angle(im_tmp));
        index_slice
        pause
        end
    complex_image(:,:,index_slice,1,:) = sliceComb;
    end
else
    complex_image = complex_3D;
end
clear complex_3D
%
if spin_dir == -1
    complex_image = conj(complex_image);
end
%
algoParams.complex_image = complex_image;
matrix_size = size(complex_image);
algoParams.matrix_size = matrix_size;
%----------------
close all;
FF_pt = 0:num_step;
FF_pt = FF_pt./num_step;
FF_table_complex = zeros(length(TE_seq - 1),length(FF_pt));
    for index_echo = 1:(length(TE_seq)-1)
    TE_0 = TE_seq(index_echo);
    TE_1 = TE_seq(index_echo + 1);
    C_TE = model_r.*exp(1i*(2*pi*TE_0.*model_f));
    C_tmp = sum(C_TE);
    C_tmp = C_tmp/abs(C_tmp);
    model_complex_0 = (1 - FF_pt) + FF_pt.*C_tmp;
    model_complex_0 = model_complex_0./abs(model_complex_0);
    %
    C_TE = model_r.*exp(1i*(2*pi*TE_1.*model_f));
    C_tmp = sum(C_TE);
    C_tmp = C_tmp/abs(C_tmp);
    model_complex_1 = (1 - FF_pt) + FF_pt.*C_tmp; 
    model_complex_1 = model_complex_1./abs(model_complex_1);    
    %
    model_complex_01 = model_complex_1.*conj(model_complex_0);
    FF_table_complex(index_echo,:) = model_complex_01;
    phase_tmp = angle(model_complex_01); 
    std_echo(index_echo) = std(diff(phase_tmp)/pi);
%    plot(phase_tmp,'o-r');
%    index_echo
%    pause
    end
    %
algoParams.FF_table_complex = FF_table_complex;
%
index_test = find(std_echo < 0.01);
algoParams.index4pair = index_test(1);
phase_echo = algoParams.Phase4Echo_ori;
delta_PhaseEcho = phase_echo(algoParams.index4pair + 1) - phase_echo(algoParams.index4pair);
delta_PhaseEcho = delta_PhaseEcho - pi_2*round(delta_PhaseEcho/pi_2);
if abs(delta_PhaseEcho) < 0.2*pi
algoParams.index4pair = index_test(2);
end
%
%algoParams.index4pair
%stop
algoParams.std_echo = std_echo;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%