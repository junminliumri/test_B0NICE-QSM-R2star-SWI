%
function [algoParams] = FatCats_defineRegion_usingPhaseFitting(algoParams)
%
pi_2 = 2*pi;
%
se = strel('disk',2);
mask4STAS = algoParams.mask4STAS;
Res_map = algoParams.Res_map;
matrix_size = algoParams.matrix_size;
BW_label = zeros(matrix_size(1:3));
for index_slice = 1:matrix_size(3)
    STAS_tmp(:,:) = mask4STAS(:,:,index_slice);
    Res_tmp(:,:) = Res_map(:,:,index_slice);
    %----------------------------
    %Res_tmp(STAS_tmp == 0) = 0;    
    Res_tmp(Res_tmp < 0.5) = 0; % half of error_bias
    Res_tmp(Res_tmp ~= 0) = 1;
    %
    mask_xy = Res_tmp;
    if sum(Res_tmp(:)) > 100
        [L, num] = bwlabel(mask_xy, 4);
        BW_label(:,:,index_slice) = L;
        %close all
        %subplot(1,2,1);imagesc(Res_tmp);colormap gray;
        %subplot(1,2,2);imagesc(L);colormap gray;
        %index_slice
        %pause
    end
end
algoParams.BW_label = BW_label;

%------------------------------------------------------
%stop



