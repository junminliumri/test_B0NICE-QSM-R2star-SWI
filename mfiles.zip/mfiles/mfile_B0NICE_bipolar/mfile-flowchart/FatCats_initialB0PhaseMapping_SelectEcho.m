%
function [algoParams] = FatCats_initialB0PhaseMapping_SelectEcho(algoParams)
%
%
pi_2 = 2*pi;
TE_seq = algoParams.TE_seq;
phase_echo = algoParams.Phase4Echo_ori;
%
%
diff_TE = diff(TE_seq);
diff2_TE = diff(diff_TE);
%
if algoParams.echo_selection == 1
    close all
    plot(algoParams.Phase4Echo_ori,'o-r');
            flag_input = 0;
            while flag_input == 0
                clear test_prompt;
                test_prompt = input('please input the value of flag_B0 (mostlikely == 1) : ');
                if ~isempty(test_prompt)
                flag_B0 = test_prompt;
                else
                flag_B0 = 1;    
                end
                
                test_prompt = input('please input the index of echo at the early side : ');
                if ~isempty(test_prompt)
                index_start = test_prompt;
                end
                
                test_prompt = input('please input the index of echo at the later side : ');
                if ~isempty(test_prompt)
                index_end = test_prompt;
                end
                
                flag_input = 1;
            end
    index_B0 = [flag_B0 index_start index_end];
else
    diff_echo = diff(unwrap(phase_echo));
    %diff_echo = pi_2 - pi_2*round(diff_echo/pi_2);
    diff_echo = sum(abs(diff_echo))/length(diff_echo);
    abs(pi_2/abs(diff_echo));
    ratio_2piOverDiff = round(abs(pi_2/abs(diff_echo)));
%    pause
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    flag_B0 = 0;index_start = 0;index_end = 0;
    if length(phase_echo) >= 3
    %
        if (1+ratio_2piOverDiff) == length(TE_seq)
        flag_B0 = 1;
        index_start = 1;
        index_end = index_start + ratio_2piOverDiff; 
        elseif (1+ratio_2piOverDiff) < length(TE_seq)
            flag_B0 = 1;
            if abs(phase_echo(1)) < 0.9*pi && abs(phase_echo(1 + ratio_2piOverDiff)) < 0.9*pi
            index_start = 1;
            index_end = index_start + ratio_2piOverDiff;
            else
            index_start = 2;
            index_end = index_start + ratio_2piOverDiff;        
            end
        elseif ratio_2piOverDiff == 3 && length(TE_seq) == 3
        flag_B0 = 2;
        index_start = 1;
        index_end = length(TE_seq);            
        else
        flag_B0 = 1;
        index_start = 1;
        index_end = length(TE_seq);
        end
    %plot(phase_echo./pi,'o-r');hold on;
    %plot(unwrap(phase_echo)./pi,'o-k');hold off;
    end
%
    index_B0 = [flag_B0 index_start index_end];

    %index_pair = algoParams.index4pair;
    %delta_PhiIni = (phase_echo(index_B0(3)) - phase_echo(index_B0(2)));
    %delta_PhiIni = delta_PhiIni - pi_2*round(delta_PhiIni/pi_2);
    %phase_fat = (-delta_PhiIni/ratio_2piOverDiff + (phase_echo(index_pair+1) - phase_echo(index_pair)))/pi;
    %if abs(phase_fat) > 0.99 && index_end < length(TE_seq)
    %index_end = index_end + 1;
    %index_B0 = [flag_B0 index_start index_end];
    %end
    if index_end < length(TE_seq)
        if abs(phase_echo(index_end+1) - phase_echo(index_start)) < abs(phase_echo(index_end) - phase_echo(index_start))
        index_end = index_end + 1;
        index_B0 = [flag_B0 index_start index_end];
        end
    end
end
%
if algoParams.echo_selection == 2
index_B0 = algoParams.index_B0;
end
index_B0
%pause
if index_B0(1) == 1
    delta_TE4B0 = TE_seq(index_B0(3)) - TE_seq(index_B0(2)); 
elseif index_B0(1) == 2 %for case 17
    delta_TE4B0 = (TE_seq(index_B0(3))+TE_seq(index_B0(2)+1) - 2*TE_seq(index_B0(2)));   
elseif index_B0(1) == 3
    delta_TE4B0 = (TE_seq(index_B0(3)) - TE_seq(index_B0(2)))*2;
end
%
algoParams.index_B0 = index_B0;
algoParams.delta_TE4B0 = delta_TE4B0;
%
if index_B0(1) == 1
    error_2pi = pi_2/(TE_seq(index_B0(3)) - TE_seq(index_B0(2)));
    delta_PhiIni = (phase_echo(index_B0(3)) - phase_echo(index_B0(2)));
    delta_PhiIni = delta_PhiIni - pi_2*round(delta_PhiIni/pi_2);
    error_bias = delta_PhiIni/(TE_seq(index_B0(3)) - TE_seq(index_B0(2)));
elseif index_B0(1) == 2
    error_2pi = pi_2/(TE_seq(index_B0(3))+TE_seq(index_B0(3)-1) - 2*TE_seq(index_B0(2)));
    diff_phase_echo = phase_echo(index_B0(3)) + phase_echo(index_B0(3)-1)- 2*phase_echo(index_B0(2));    
    %diff_phase_echo/pi
    if abs(diff_phase_echo) > pi
    diff_phase_echo = diff_phase_echo - sign(diff_phase_echo)*pi_2;
    error_bias = diff_phase_echo/(TE_seq(index_B0(3))+TE_seq(index_B0(3)-1) - 2*TE_seq(index_B0(2)));        
    else    
    %diff_phase_echo = sign(diff_phase_echo)*pi_2 - diff_phase_echo;
    error_bias = diff_phase_echo/(TE_seq(index_B0(3))+TE_seq(index_B0(3)-1) - 2*TE_seq(index_B0(2)));
    end
    % 
elseif index_B0(1) == 3
    error_2pi = pi_2/algoParams.delta_TE4B0;
    delta_PhiIni = 2*(phase_echo(index_B0(3)) - phase_echo(index_B0(2)));
    delta_PhiIni = delta_PhiIni - pi_2*round(delta_PhiIni/pi_2);
    error_bias = delta_PhiIni/(TE_seq(index_B0(3)) - TE_seq(index_B0(2)));    
end
%
%index_B0
%pause
error_bias = error_bias/pi_2;
algoParams.error_2pi = error_2pi;
algoParams.error_bias = error_bias;
%
model_r = algoParams.model_r;
algoParams.model_f_ori = algoParams.model_f;
model_f = algoParams.model_f;
model_f = model_f - error_bias;
%clear algoParams.error_bias;
%
close all;
num_step = algoParams.num_step;
index_tmp = find(abs(phase_echo) < 0.9*pi);
index_start = index_tmp(1);
algoParams.index_start = index_start;
%clear index_tmp;
%index_start = 1;
%---------------------
%
FF_pt = 0:num_step;
FF_pt = FF_pt./num_step;
complex_FFpt_table = zeros((length(TE_seq) - index_start),length(FF_pt));
%
    TE_0 = TE_seq(index_start);
    C_TE = model_r.*exp(1i*(2*pi*TE_0.*model_f));
    C_tmp = sum(C_TE);
    C_tmp = C_tmp/abs(C_tmp);
    model_complex_0 = (1 - FF_pt) + FF_pt.*C_tmp;
    model_complex_0 = model_complex_0./abs(model_complex_0);    
    %
    for index_TE = (index_start + 1):length(TE_seq)
    TE_1 = TE_seq(index_TE);    
    C_TE = model_r.*exp(1i*(2*pi*TE_1.*model_f));
    C_tmp = sum(C_TE);
    C_tmp = C_tmp/abs(C_tmp);
    %
    model_complex_1 = (1 - FF_pt) + FF_pt.*C_tmp; 
    model_complex_1 = model_complex_1./abs(model_complex_1); 
    %
    complex_FFpt_table((index_TE - index_start),:) = model_complex_1.*conj(model_complex_0);
    %index_TE 
    %pause
    end
algoParams.complex_FFpt_table = complex_FFpt_table;   
    
    %
phase_echo = zeros(1,length(TE_seq));
mag_echo = zeros(1,length(TE_seq));
    for index_echo = 1:length(TE_seq)
    TE_tmp = TE_seq(index_echo);
    model_complex = model_r.*exp(1i.*(2*pi*TE_tmp.*model_f));
    model_complex_sum = sum(model_complex);
    phase_echo(index_echo) = angle(model_complex_sum);
    mag_echo(index_echo) = abs(model_complex_sum);
    end
%close all
%plot(phase_echo/pi,'o-r');
%pause
algoParams.phase_echo = phase_echo;
%

%