%
function [algoParams] = FatCats_FFfromPhase(algoParams)
%
pi_2 = 2*pi;
%
TE_seq = algoParams.TE_seq;
num_step = algoParams.num_step;
phase_echo = algoParams.phase_echo;
mask4STAS = algoParams.mask4STAS;
complex_image = algoParams.complex_image;
B0_map = algoParams.B0_map_raw;
error_2pi = algoParams.error_2pi;
%error_bias = algoParams.error_bias;
index_B0 = algoParams.index_B0;
%

matrix_size = size(complex_image);

%
delta_TE4B0 = algoParams.delta_TE4B0;
%--------------------------
index_tmp = find(abs(phase_echo) < 0.9*pi);
index_start = index_tmp(1);
index_start = algoParams.index_start;
%clear index_tmp;
%index_start = 1;
%---------------------
complex_FFpt_table = algoParams.complex_FFpt_table;    
%---------------------------------------------------------
complex_B0Map_table = zeros(matrix_size(1),matrix_size(2),matrix_size(3),(matrix_size(5)-index_start));
for index_slice = 1:matrix_size(3)
    B0_unit(:,:) = B0_map(:,:,index_slice);
    %B0_unit = medfilt2(B0_unit,[7 7]);
    for index_echo = (index_start+1):length(TE_seq)
        B0Map_tmp = B0_unit*(TE_seq(index_echo) - TE_seq(index_start));
        B0Map_tmp = medfilt2(B0Map_tmp,[3 3]);
        B0Map_tmp = exp(-1i*B0Map_tmp);
        complex_B0Map_table(:,:,index_slice,(index_echo - index_start)) = B0Map_tmp; 
        %figure(2)
        %imagesc(angle(B0Map_tmp),[-pi pi]);colormap jet;axis square;axis off;
        %index_echo
        %index_slice
        %pause
    end
end
%---------------------------------------------------------
S_10 = zeros(matrix_size(1),matrix_size(2),matrix_size(3),(length(TE_seq)-index_start));
for index_slice = 1:matrix_size(3)
    %complex_image = squeeze(complex_image);
    S_0 = complex_image(:,:,index_slice,index_start);
    mag_S_0 = abs(S_0);
    nom_S_0 = S_0./mag_S_0;
    %
    for index_echo = (index_start+1):length(TE_seq)
        %
    B0Map_tmp(:,:) = complex_B0Map_table(:,:,index_slice,(index_echo - index_start));    
    %
    %index_slice
    %index_echo
    %index_start
    %size(complex_image)
    S_10(:,:,index_slice,(index_echo - index_start)) = complex_image(:,:,index_slice,index_echo).*conj(nom_S_0);
    S_10(:,:,index_slice,(index_echo - index_start)) = S_10(:,:,index_slice,(index_echo - index_start))./mag_S_0;
    %
    S_10(:,:,index_slice,(index_echo - index_start)) = S_10(:,:,index_slice,(index_echo - index_start)).*B0Map_tmp;    
    %
    %im_tmp(:,:) = S_10(:,:,index_slice,(index_echo - index_start));
    %phase_0 = angle(im_tmp);
    %
    %figure(2)
    %imagesc(phase_0,[-pi pi]);colormap jet;axis square;axis off;
    %index_echo
    %index_slice
    %pause
    end
end
%-------------------------------------------------------

jj = 1;
for index_echo = (index_start+1):length(TE_seq)
    if index_B0(1) == 1
        if abs((TE_seq(index_echo) - TE_seq(index_start))/delta_TE4B0 - 1) > 0.2   
        index_echo_FF(jj) = index_echo;
        jj = jj + 1;
        end
    else
        index_echo_FF(jj) = index_echo;
        jj = jj + 1;        
    end
end

%-------------------------------------------------------
FF_map = zeros(matrix_size(1),matrix_size(2),matrix_size(3));
Bias_map = zeros(matrix_size(1),matrix_size(2),matrix_size(3));
Res_map = ones(matrix_size(1),matrix_size(2),matrix_size(3));
%---------
for index_slice = 1:matrix_size(3)
    for index_y = 1:matrix_size(1)
        for index_x = 1:matrix_size(2)
            S10_pt = S_10(index_y,index_x,index_slice,:);
            S10_pt = squeeze(S10_pt);
            S10_pt_sos = 0;
                S10_pt_sum = 0;
                    for jj = 1:length(index_echo_FF)
                    index_echo = index_echo_FF(jj);
                    S10_pt_tmp = S10_pt(index_echo - index_start);    
                    CS_FFpt = complex_FFpt_table(index_echo - index_start,:);
                    CS_FFpt = squeeze(CS_FFpt);
                    %size(CS_FFpt)
                    S10_pt_sos = S10_pt_sos +  abs(angle(conj(CS_FFpt).*S10_pt_tmp)/(TE_seq(index_echo) - TE_seq(index_start)));                 
                    S10_pt_sum = S10_pt_sum +  (angle(conj(CS_FFpt).*S10_pt_tmp)/(TE_seq(index_echo) - TE_seq(index_start)));
                    %
                    end
                    %
                    [residule_tmp min_FF_index_tmp] = min(abs(S10_pt_sos));
                    %
                    residule_tmp = residule_tmp/(error_2pi);
                    residule_tmp = residule_tmp/length(index_echo_FF);
                    bias_pt = S10_pt_sum(min_FF_index_tmp)/length(index_echo_FF);
                    %
            FF_map(index_y,index_x,index_slice) = (min_FF_index_tmp - 1)/num_step;       
            Res_map(index_y,index_x,index_slice) = residule_tmp;
            Bias_map(index_y,index_x,index_slice) = bias_pt;
        end
    end
end

algoParams.FFfromPhase = FF_map;
algoParams.Res_map = Res_map;
algoParams.Bias_map = Bias_map;
%------------------------------------------------------
%stop



