%
function [algoParams] = FatCats_SmoothenB0(algoParams)
%
pi_2 = 2*pi;

mag(:,:,:) = abs(algoParams.complex_image(:,:,:,1,1));
mag(isnan(mag)) = 0;
mag = mat2gray(mag);

%index_B0 = algoParams.index_B0;
B0 = (algoParams.B0_map_raw).*algoParams.delta_TE4B0;
lim_shift = max(algoParams.index_shift) + 1;
ShiftPhase = lim_shift*pi_2;


BW_label = algoParams.BW_label;
matrix_size = algoParams.matrix_size;

for index_slice = 1:matrix_size(3)
    mag_slice(:,:) = mag(:,:,index_slice);
    
    B0_slice(:,:) = B0(:,:,index_slice);
    B0_slice(isnan(B0_slice)) = 0;
    B0_slice_out = B0_slice;
    
    BW_slice(:,:) = BW_label(:,:,index_slice);
    
    %figure(1);
    %subplot(1,2,1);imagesc(BW_slice,[0 5]);colormap gray
    %subplot(1,2,2);imagesc(B0_slice,[-ShiftPhase ShiftPhase]);colormap gray;
    
    mask_ref = zeros(matrix_size(1:2));
    mask_ref(BW_slice == 1) = 1;
    [rr_ref,cc_ref]=find(mask_ref);
    %
    for index_rr = 2:max(BW_slice(:))
    bb = -1*ShiftPhase:0.25*pi:1*ShiftPhase;
    CostSum = zeros(length(bb),1);    
        
    mask_by = zeros(matrix_size(1:2));
        
    mask_rr = zeros(matrix_size(1:2));
    mask_rr(BW_slice == index_rr) = 1;
    
    [rr,cc]=find(mask_rr);
    if sum(mask_rr(:)) > algoParams.minAreaUsingFlip

        for index_kk = 1:length(rr)
                index_x = rr(index_kk);
                index_y = cc(index_kk);
                for index_kk_ref = 1:length(rr_ref)
                    index_r_x = rr_ref(index_kk_ref);
                    index_r_y = cc_ref(index_kk_ref);
                        dist = (index_x - index_r_x)^2 + (index_y - index_r_y)^2;
                        dist = dist^0.5;
                        if dist < 10
                            
                            if mag_slice(index_x,index_y) > mag_slice(index_r_x,index_r_y)
                            mag_pt = mag_slice(index_r_x,index_r_y);
                            else
                            mag_pt = mag_slice(index_x,index_y);    
                            end
                            %
                            
                            for index_bb = 1:length(bb)
                            phase_diff = abs(B0_slice(index_x,index_y) + bb(index_bb) - B0_slice(index_r_x,index_r_y));
                            CostSum(index_bb) = CostSum(index_bb) + (phase_diff/dist)*mag_pt;
                            end
                                            
                        mask_by(index_x,index_y) = 1;
                        mask_by(index_r_x,index_r_y) = 2;
                        end

                end
        end
    
    %end
    [yy II] = min(CostSum);

    %yy
    %II
    B0_slice_out(mask_rr == 1) = B0_slice_out(mask_rr == 1) + ShiftPhase*round(bb(II)/ShiftPhase);
    
    %figure(5)
    %plot(CostSum,'o-r');
    %index_slice
    %pause
    
    end
    end
    %
    algoParams.B0_map_raw(:,:,index_slice) = B0_slice_out./algoParams.delta_TE4B0;
    %index_slice
end

%------------------------------------------------------
%stop



