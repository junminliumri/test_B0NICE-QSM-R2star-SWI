%
function [algoParams] = FatCats_defineRegion_usingDiffFF(algoParams)
%
pi_2 = 2*pi;
%-------------------------------------------------------
ff_diff = algoParams.FFfromPhase - algoParams.FF_raw_mean;
ff_diff(abs(ff_diff)<0.7) = 0;
ff_diff(ff_diff ~= 0) = 1;
%ff_diff(abs(algoParams.FF_raw_mean - 0.5) < 0.1) = 0;

ff_diff(algoParams.mask4STAS == 0) = 0;
%figure(1);
%imshow3D(ff_diff);colormap gray;
%
matrix_size = algoParams.matrix_size;
for index_slice = 1:matrix_size(3)
    %
    mask_tmp = zeros(matrix_size(1:2));
    mask_xy(:,:) = ff_diff(:,:,index_slice);
    if sum(mask_xy(:)) > algoParams.minAreaUsingFlip
        [L, num] = bwlabel(mask_xy, 4);
        s_tt  = regionprops(L, 'area');
        [y_area_tt I_area_tt] = sort([s_tt.Area],'descend');
        if y_area_tt(1) > algoParams.minAreaUsingFlip
            ll = 1;
            ff_diff_slice = zeros(matrix_size(1:2));
            flag_done = 0;
            while flag_done == 0
                if y_area_tt(ll) > algoParams.minAreaUsingFlip
                ff_diff_tmp = zeros(matrix_size(1:2));
                ff_diff_tmp(L == I_area_tt(ll)) = 1;
                ff_diff_slice(L == I_area_tt(ll)) = 1;
                FFfromPhase_slice(:,:) = algoParams.FFfromPhase(:,:,index_slice);
                FFfromPhase_vec = FFfromPhase_slice.*ff_diff_tmp;
                FFfromPhase_vec = FFfromPhase_vec(:);
                FFfromPhase_vec(FFfromPhase_vec == 0) = [];
                mean_FFfromPhase = mean(FFfromPhase_vec);
                std_FFfromPhase = std(FFfromPhase_vec);
                clear FFfromPhase_vec;
                mask_tmp = zeros(matrix_size(1:2));
                mask_tmp(abs(FFfromPhase_slice - mean_FFfromPhase) < 4*std_FFfromPhase) = 1;
                mask_tmp = imfill(mask_tmp,'holes');
                else
                flag_done = 1;    
                end
                ll = ll + 1;
            end
            ff_diff(:,:,index_slice) = mask_tmp;
        else
        ff_diff(:,:,index_slice) = 0;    
        end
    else
        ff_diff(:,:,index_slice) = 0;
    end
        %close all
        %subplot(1,2,1);imagesc(ff_diff(:,:,index_slice));colormap gray;
        %subplot(1,2,2);imagesc(mask_tmp);colormap gray;
        %index_slice
        %pause
end

%ff_diff(algoParams.mask4STAS == 0) = 0;
algoParams.ff_diff = ff_diff;
algoParams.BW_label = ff_diff;



