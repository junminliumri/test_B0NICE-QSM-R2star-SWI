function [algoParams] = FatCats_initialB0PhaseMapping_RawB0(algoParams)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
%-------------------------
[algoParams] = FatCats_BuildComplexB0(algoParams);
matrix_size = algoParams.matrix_size;
%generating masks used ofr phase unwrapping
algoParams.complex4mask = algoParams.complex_image(:,:,:,1,2);
        if algoParams.upSampling > 1
            complex4mask_ori = algoParams.complex4mask;
            [algoParams.complex4mask] = kSpace_zeroPad (algoParams.complex4mask, [matrix_size(1) matrix_size(2) matrix_size(3)* algoParams.upSampling]);
        
        end
[algoParams] = FatCats_mask_generation(algoParams);
        %
%calculating B0 raw
        if algoParams.upSampling > 1
        [algoParams.complex_B0] = kSpace_zeroPad (algoParams.complex_B0, [matrix_size(1) matrix_size(2) matrix_size(3)* algoParams.upSampling]);
        end
[algoParams] = FatCats_B0_raw(algoParams);

[algoParams] = FatCats_B0Raw_Phase2Freq(algoParams);
        %
        if algoParams.upSampling > 1
         algoParams.complex4mask = complex4mask_ori;    
        [algoParams] = FatCats_mask_generation(algoParams);
        end
end

