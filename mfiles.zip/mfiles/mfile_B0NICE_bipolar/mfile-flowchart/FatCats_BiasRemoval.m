function [outParams] = FatCats_BiasRemoval( algoParams )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
%#########################################  
    [FF4bias]= FatCats_getSpecies(algoParams);
    B0Map_fixed = algoParams.B0_map_raw - (2*pi*algoParams.error_bias).*FF4bias;
    B0Map_fixed = B0Map_fixed./(2*pi);
    
    [FF4bias]= FatCats_getSpecies(algoParams);
outParams.fm = B0Map_fixed;
outParams.FF = FF4bias;
outParams.R2star = algoParams.R2star_map_raw;
%