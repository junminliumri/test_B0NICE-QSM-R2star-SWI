function [algoParams] = FatCats_PhaseErrorCorrection_phantom(algoParams)
%--------------
pi_2 = 2*pi;
%make sure the peak of water-pixels 
    %determined by using magnitude have th phase values around zero  
    [algoParams] = FatCats_PhaseFromMag(algoParams);
    [algoParams] = FatCats_globalCheckB0(algoParams);
    %-------------------------
    flag_pass = 1;
    if flag_pass == 1
    % divide B0 map into regions using algoParams.error_2pi/2 as threshold
    for diff_step = 1:1
    algoParams.diff_step = 2^(diff_step-1);
    [algoParams] = FatCats_defineRegion_usingPhaseGradient(algoParams);
    [algoParams] = FatCats_regionalCheckB0( algoParams);
    %stop
    end%
    %
    %imagesc(algoParams.B0_map_raw);
    %pause
    %
    if algoParams.index_B0(1) == 1 && (algoParams.index_B0(3)-algoParams.index_B0(2)) > 2;

        [algoParams] = FatCats_FFfromPhase(algoParams);
        [algoParams] = FatCats_defineRegion_usingPhaseFitting(algoParams);
        [algoParams] = FatCats_regionalCheckB0(algoParams);
    end
        [algoParams] = FatCats_FFfromPhase(algoParams);
        [algoParams] = FatCats_defineRegion_usingDiffFF(algoParams);
        [algoParams] = FatCats_regionalCheckB0( algoParams);
    %
    end 
    %---------------------------------------------
    algoParams.B0Map_fixed = algoParams.B0_map_raw;
    %
%---------------------------------------------
