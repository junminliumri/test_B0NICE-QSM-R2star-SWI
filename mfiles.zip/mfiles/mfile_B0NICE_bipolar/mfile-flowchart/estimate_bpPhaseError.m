function [LinearPhaseError_3D] = estimate_bpPhaseError(complex_diff)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
%
matrix_size = size(complex_diff);
        if length(matrix_size) == 2
            matrix_size(3) = 1;
        end 

algoParams.complex_image = complex_diff;
algoParams.th4unwrap = 0.0;
algoParams.th4supp = 1.0;
algoParams.th4STAS = 2.0;
algoParams.complex4mask = complex_diff;
%figure(1);imshow3Dfull(angle(complex_diff),[-pi pi]);colormap gray;
%
[algoParams] = FatCats_mask_generation(algoParams);
algoParams.unwrap_mode = 3;
[unwrap_BPphaseError] = PUROR2D(complex_diff,algoParams.mask4unwrap,algoParams.mask4supp,algoParams.mask4STAS);
%figure(2);imshow3Dfull(unwrap_BPphaseError,[-pi pi]);colormap gray;
        if algoParams.unwrap_mode == 3 && matrix_size(3) > 5
        debug_PUROR = 0;
        [ unwrap_phase unwrap_phase_tmp] = StackSlice_Igor(unwrap_BPphaseError, unwrap_BPphaseError, algoParams.mask4STAS);
    
            for index_slice = 1:matrix_size(3)
            [region_label size_area] = BW_label_region(unwrap_phase(:,:,index_slice),algoParams.mask4supp(:,:,index_slice), debug_PUROR);
                if isempty(size_area)
                area_max(index_slice) = 0;
                else
                [y I] = sort(size_area,'descend');
                area_max(index_slice) = y(I(1));
                end
            end    
            area_max(1) = 0;
            area_max(matrix_size(3)) = 0;
        %
        unwrap_BPphaseError = unwrap_phase;
        %[ unwrap_BPphaseError ] = PUROR3D( unwrap_phase, area_max,complex_diff,algoParams.mask4unwrap, algoParams.mask4supp, algoParams.mask4STAS, debug_PUROR ); 
        end
        %
        %figure(3);imshow3Dfull(unwrap_BPphaseError,[-2*pi 2*pi]);colormap gray;
        %
        matrix_size = size(unwrap_BPphaseError);
        if length(matrix_size) == 2
            matrix_size(3) = 1;
        end    
        for index_slice = 1:matrix_size(3)
        phase_vari(:,:,index_slice) = PhaseDerivativeVariance(unwrap_BPphaseError(:,:,index_slice));
        end
        %
        order = 1;
        [LinearPhaseError_3D] = bpPhaseError_polyfitn(unwrap_BPphaseError,phase_vari,order); 
end
%
function [base] = bpPhaseError_polyfitn(PhaseError,phase_vari,order)
    %
    map = PhaseError;
    matrix_size = size(map);
    [x, y, z] = size(map);

    brain_mask = phase_vari;
    brain_mask(brain_mask > 0.5) = 0;
    brain_mask(brain_mask ~= 0) = 1;
    for index_slice = 1:matrix_size(3)
    mask_slice(:,:) = brain_mask(:,:,index_slice);
    [L, num] = bwlabel(mask_slice, 4);
    s  = regionprops(L, 'area');
    [y_area I_area] = sort([s.Area],'descend');
        if ~isempty(y_area(1))
    	mask_slice(L ~= I_area(1)) = 0;
    	brain_mask(:,:,index_slice) = mask_slice;
        else
        brain_mask(:,:,index_slice) = 0;    
        end
    end
    %
    flag_mode = 3;
    %
    if flag_mode == 2
    for index_slice = 1:matrix_size(3)
        map_2D(:,:) = map(:,:,index_slice);
        mask_2D(:,:) = brain_mask(:,:,index_slice);
        %mask_2D = mask_2D.*square_ROI;
        maproi = logical(mask_2D);

    %Get the FOV dimensions from the matrix dimensions:
    X = (-floor(x/2):(x - floor(x/2) - 1)).*1;
    Y = (-floor(y/2):(y - floor(y/2) - 1)).*1;
    %Z = (-floor(z/2):(z - floor(z/2) - 1)).*1;
    
    % Compute the k^2 values:
    X = reshape(X, [x 1]);   
    Y = reshape(Y, [1 y]);
    %Z = reshape(Z, [1 1 z]);

    %Create the basis functions:
    X = X(:, ones(1,y), ones(1,z));
    Y = Y(ones(1,x), :, ones(1,z));
    %Z = Z(ones(1,x), ones(1,y), :);

    %Note that maproi is a logical-type variable and, thus, roi is logical-type.
    roi = maproi;

    %Decimate:
    %A = [X(roi) Y(roi) Z(roi)];
    A = [X(roi) Y(roi)];
    clear X
    clear Y
    %clear Z

    P = polyfitn(A, map_2D(roi), order);

    P.Coefficients
    stop
    polyn2sym(P)
    %polyn2sympoly(P)
    
    base = map_2D;

    base(roi) = polyvaln(P,A);
    %size(base)
    %size(map_2D)
    LFSpostFilt = map_2D  - base*1.0;
    %PhaseError_residue = LFSpostFilt;
        debug = 0;
        if debug == 1
        figure(1);
        subplot(2,2,1);imagesc(map_2D);colormap(gray);%caxis([-12 12])
        subplot(2,2,2);imagesc(mask_2D);colormap(gray);
        subplot(2,2,3);imagesc(LFSpostFilt);colormap(gray);%caxis([-12 12])
        subplot(2,2,4);imagesc(base);colormap(gray);%caxis([-25 25])
        end
        index_slice
        pause
    end
    else
    maproi = logical(brain_mask);

    %Get the FOV dimensions from the matrix dimensions:
    X = (-floor(x/2):(x - floor(x/2) - 1)).*1;
    Y = (-floor(y/2):(y - floor(y/2) - 1)).*1;
    Z = (-floor(z/2):(z - floor(z/2) - 1)).*2;
    
    % Compute the k^2 values:
    X = reshape(X, [x 1]);   
    Y = reshape(Y, [1 y]);
    Z = reshape(Z, [1 1 z]);

    %Create the basis functions:
    X = X(:, ones(1,y), ones(1,z));
    Y = Y(ones(1,x), :, ones(1,z));
    Z = Z(ones(1,x), ones(1,y), :);

    %Note that maproi is a logical-type variable and, thus, roi is logical-type.
    roi = maproi;

    %Decimate:
    A = [X(roi) Y(roi) Z(roi)];

    %clear X
    %clear Y
    %clear Z

    P = polyfitn(A, map(roi), order);

    P_0 = P.Coefficients(length(P.Coefficients));
    P_0 = P_0 - 2*pi*round(P_0/2/pi);
    P.Coefficients(length(P.Coefficients)) = P_0;
    %P.Coefficients
    %polyn2sym(P)
    %polyn2sympoly(P)
    base = map;
    %
    clear roi;
    mask_all = ones(matrix_size);
    roi_all = logical(mask_all);
    clear A;
    A = [X(roi_all) Y(roi_all) Z(roi_all)];
    
    clear X
    clear Y
    clear Z
    
    %
    base(roi_all) = polyvaln(P,A);
    %LFSpostFilt = map  - base*1.0;
    %PhaseError_residue = LFSpostFilt;
    debug = 0;
    if debug == 1
        for index_slice = 1:matrix_size(3)
        figure(1);
        subplot(2,2,1);imagesc(map(:,:,index_slice));colormap(gray);%caxis([-12 12])
        subplot(2,2,2);imagesc(brain_mask(:,:,index_slice));colormap(gray);
        subplot(2,2,3);imagesc(LFSpostFilt(:,:,index_slice));colormap(gray);%caxis([-12 12])
        subplot(2,2,4);imagesc(base(:,:,index_slice));colormap(gray);%caxis([-25 25])
        index_slice
        pause
        end
    end
    end
    %
    %save([PhaseErrorfile,'_polyfitn.mat'],'PhaseError');
    %
end

