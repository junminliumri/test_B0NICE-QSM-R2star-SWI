function [algoParams] = FatCats_PhaseErrorCorrection(algoParams)
%--------------
pi_2 = 2*pi;
%make sure the peak of water-pixels 
    %determined by using magnitude have th phase values around zero  
    [algoParams] = FatCats_PhaseFromMag(algoParams);
    [algoParams] = FatCats_globalCheckB0(algoParams);
    %-------------------------
    % divide B0 map into regions using algoParams.error_2pi/2 as threshold
    for diff_step = 1:1
    algoParams.diff_step = 2^(diff_step-1);
    [algoParams] = FatCats_defineRegion_usingPhaseGradient(algoParams);
    [algoParams] = FatCats_regionalCheckB0( algoParams);
    %stop
    end%
    %
    %imagesc(algoParams.B0_map_raw);
    %pause
    %
    if algoParams.index_B0(1) == 1 && (algoParams.index_B0(3)-algoParams.index_B0(2)) > 2;

        [algoParams] = FatCats_FFfromPhase(algoParams);
        [algoParams] = FatCats_defineRegion_usingPhaseFitting(algoParams);
        [algoParams] = FatCats_regionalCheckB0(algoParams);
    end
        [algoParams] = FatCats_FFfromPhase(algoParams);
        [algoParams] = FatCats_defineRegion_usingDiffFF(algoParams);
        [algoParams] = FatCats_regionalCheckB0( algoParams);
    %
    %
    %algoParams.diff_step = 1;
    %[algoParams] = FatCats_defineRegion_usingPhaseGradient(algoParams);
    %[algoParams] = FatCats_SmoothenB0(algoParams);
    
    %stop
    %index_B0 = algoParams.index_B0;
    %B0 = (algoParams.B0_map_raw).*(algoParams.TE_seq(index_B0(3))-algoParams.TE_seq(index_B0(2)));
    %lim_shift = max(algoParams.index_shift);
    %B0 = B0 - ((lim_shift+1)*pi_2)*round(B0./(2*lim_shift*pi_2));
    %figure(1);imshow3D(B0,[-lim_shift*pi_2 lim_shift*pi_2]);colormap gray;
    %mask_B0 = zeros(algoParams.matrix_size(1:3));
    %mask_B0(abs(B0) > lim_shift*pi_2) = 1;
    %figure(2);imshow3D(mask_B0,[0 1]);colormap gray;
    %B0 = B0./(algoParams.TE_seq(index_B0(3))-algoParams.TE_seq(index_B0(2)));
    %pause
    
    %[algoParams] = FatCats_BW_label_edge(algoParams);
    %[ newImages ] = FixB0map_UsingFilling( algoParams );
    %algoParams.B0_map_raw = newImages; 
    %
    %---------------------------------------------
    algoParams.B0Map_fixed = algoParams.B0_map_raw;
    %
%---------------------------------------------
