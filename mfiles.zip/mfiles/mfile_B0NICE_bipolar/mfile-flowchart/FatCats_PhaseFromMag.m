%
function [algoParams] = FatCats_PhaseFromMag(algoParams)
%
B0_strength = algoParams.B0_strength; % unit:T
spin_dir = 1;
TE_seq = algoParams.TE_seq;% unit:s
%
model_r = [0.0870 0.6930 0.1280 0.0040 0.0390 0.0480];
model_f = [-242.7060 -217.1580 -166.0620 -123.9078 -24.9093 38.3220];
model_f = model_f.*(B0_strength/1.5);
model_f = model_f - algoParams.error_bias;
%
%------------------------------
matrix_size = algoParams.matrix_size;
FF = algoParams.FF_raw_mean;
complexFromFF = zeros(matrix_size(1), matrix_size(2), matrix_size(3), matrix_size(5));
for index_echo = 1:length(TE_seq)
    TE_tmp = TE_seq(index_echo);
    model_complex = sum(model_r.*exp(1i.*(2*pi*TE_tmp.*model_f)));
    model_complex = model_complex/abs(model_complex);
    %
    if index_echo == 1
    complex_1stEcho = (1 - FF) + FF*model_complex;
    else
    complex_lateEcho = (1 - FF) + FF*model_complex;
    complex_lateEcho = complex_lateEcho.*conj(complex_1stEcho);
    complexFromFF(:,:,:,index_echo) = complex_lateEcho;
    end
    %
end
complexFromFF(:,:,:,1) = 1;
algoParams.complexFromFF = complexFromFF./abs(complexFromFF);
%