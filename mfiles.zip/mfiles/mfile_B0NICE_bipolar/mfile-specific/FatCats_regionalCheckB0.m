%
function [algoParams] = FatCats_regionalCheckB0( algoParams) 
%
complex_image = algoParams.complex_image;
mask4STAS = algoParams.mask4STAS;
%
%index_echo = algoParams.index4pair;
matrix_size = size(complex_image);
%delta_TE = algoParams.delta_TE4pair;
%delta_PhaseEcho = algoParams.theory_Phase4pair;
TEratio = round(algoParams.delta_TE4B0/(algoParams.TE_seq(2)-algoParams.TE_seq(1)));
index_shift = -(TEratio-1):0.5:(TEratio-1);
if length(index_shift) == 1
index_shift = [-1 0 1];
end
index_shift(index_shift == 0) = [];
index_shift = [0 index_shift];
algoParams.index_shift = index_shift;
%-------------------------
B0_map_ori = algoParams.B0_map_raw;
for index_ss = 1:length(index_shift)
    B0_map_shift(:,:,:,index_ss) = B0_map_ori + index_shift(index_ss)*algoParams.error_2pi;
end
%
complex_HP = zeros(matrix_size(1),matrix_size(2),matrix_size(3),matrix_size(5));
phase_diff = zeros(matrix_size(1),matrix_size(2),matrix_size(3),matrix_size(5));
PhaseDiff_ss = zeros(matrix_size(1),matrix_size(2),matrix_size(3),length(index_shift));
for index_ss = 1:length(index_shift)
    for index_echo = matrix_size(5):-1:1
        complex_HP(:,:,:,index_echo) = complex_image(:,:,:,1,index_echo).*conj(complex_image(:,:,:,1,1));
        complex_HP(:,:,:,index_echo) = complex_HP(:,:,:,index_echo).*exp(-1i*B0_map_shift(:,:,:,index_ss)*(algoParams.TE_seq(index_echo)-algoParams.TE_seq(1)));
        phase_diff(:,:,:,index_echo) = angle(complex_HP(:,:,:,index_echo).*conj(algoParams.complexFromFF(:,:,:,index_echo)));
        phase_diff(isnan(phase_diff)) = 0;
        %figure(1)
        %subplot(2,2,1);imagesc(angle(algoParams.complexFromFF(:,:,index_slice,index_echo)),[-pi pi]);colormap gray;
        %subplot(2,2,2);imagesc(angle(complex_HP),[-pi pi]);colormap gray;
        %subplot(2,2,3);imagesc(algoParams.FF_raw_mean(:,:,index_slice),[0 1]);colormap gray;
        %subplot(2,2,4);imagesc(phase_diff,[-pi pi]);colormap gray;
        %index_echo
        %index_slice
        %index_ss
        %pause
    end
    PhaseDiff_ss(:,:,:,index_ss) = sum(abs(phase_diff),4);
    %imshow3D(PhaseDiff_ss(:,:,:,index_ss));colormap gray;
    %index_ss
    %pause
end
%
%algoParams.ErrorRatio_phase = ones(1,algoParams.matrix_size(3));
%complex_pair(:,:,:) = complex_image(:,:,:,1,index_echo + 1).*conj(complex_image(:,:,:,1,index_echo));
for index_slice = 1:matrix_size(3)
    %
    %if algoParams.ErrorRatio_phase(index_slice) > 0.05 
    %-------------------
    %mask_slice(:,:) = mask4STAS(:,:,index_slice);  
    BW_slice(:,:) = algoParams.BW_label(:,:,index_slice);
    %
    B0_out(:,:) = B0_map_ori(:,:,index_slice);
    %figure(1)
    %subplot(1,2,1);imagesc(B0_out);colormap gray;
    for index_BW = 1:max(BW_slice(:))
        for index_ss = 1:length(index_shift)
            PhaseDiff_slice(:,:) = PhaseDiff_ss(:,:,index_slice,index_ss);
            PhaseDiff_slice(BW_slice ~= index_BW) = 0;
            PhaseDiff_slice(isnan(PhaseDiff_slice)) = 0;
            sum_vec(index_ss) = sum(PhaseDiff_slice(:));
        end
        %error_ratio
        %pause
        [mm Imin] = min(sum_vec);
        index_Imin = find(sum_vec == mm);
        II = index_Imin(1);
        if length(index_Imin) == 2 && abs(index_shift(index_Imin(1))) > abs(index_shift(index_Imin(2)))
        II = index_Imin(2);
        end
        %
        %II
        %pause
        B0_ss(:,:) = B0_map_shift(:,:,index_slice,II);
        B0_out(BW_slice == index_BW) = B0_ss(BW_slice == index_BW);
        %
    end
    %subplot(1,2,2);imagesc(B0_out);colormap gray;
    algoParams.B0_map_raw(:,:,index_slice) = B0_out;
    %index_slice
    %pause
    %-----
    %end
end
%---------------------------
B0_map_ori = algoParams.B0_map_raw;
index_shift = algoParams.index_shift;
for index_ss = 1:length(index_shift)
    B0_map_shift(:,:,:,index_ss) = B0_map_ori + index_shift(index_ss)*algoParams.error_2pi;
end
%
complex_HP = zeros(matrix_size(1),matrix_size(2),matrix_size(3),matrix_size(5));
phase_diff = zeros(matrix_size(1),matrix_size(2),matrix_size(3),matrix_size(5));
PhaseDiff_ss = zeros(matrix_size(1),matrix_size(2),matrix_size(3),length(index_shift));
for index_ss = 1:length(index_shift)
    for index_echo = matrix_size(5):-1:1
        complex_HP(:,:,:,index_echo) = complex_image(:,:,:,1,index_echo).*conj(complex_image(:,:,:,1,1));
        complex_HP(:,:,:,index_echo) = complex_HP(:,:,:,index_echo).*exp(-1i*B0_map_shift(:,:,:,index_ss)*(algoParams.TE_seq(index_echo)-algoParams.TE_seq(1)));
        phase_diff(:,:,:,index_echo) = angle(complex_HP(:,:,:,index_echo).*conj(algoParams.complexFromFF(:,:,:,index_echo)));
        phase_diff(isnan(phase_diff)) = 0;
        %figure(1)
        %subplot(2,2,1);imagesc(angle(algoParams.complexFromFF(:,:,index_slice,index_echo)),[-pi pi]);colormap gray;
        %subplot(2,2,2);imagesc(angle(complex_HP),[-pi pi]);colormap gray;
        %subplot(2,2,3);imagesc(algoParams.FF_raw_mean(:,:,index_slice),[0 1]);colormap gray;
        %subplot(2,2,4);imagesc(phase_diff,[-pi pi]);colormap gray;
        %index_echo
        %index_slice
        %index_ss
        %pause
    end
    PhaseDiff_ss(:,:,:,index_ss) = sum(abs(phase_diff),4);
    %imshow3D(PhaseDiff_ss(:,:,:,index_ss));colormap gray;
    %index_ss
    %pause
end
%
%close all
%PhaseDiff_ori(:,:,:) = PhaseDiff_ss(:,:,:,1);
%[yy ii] = min(PhaseDiff_ss,[],4);
%figure(1);imshow3D(yy);colormap gray;
%figure(2);imshow3D(ii);colormap gray;
%figure(3);imshow3D((PhaseDiff_ori-yy)./PhaseDiff_ori,[0 1.0]);colormap gray;
%pause
%stop
%----------------------

