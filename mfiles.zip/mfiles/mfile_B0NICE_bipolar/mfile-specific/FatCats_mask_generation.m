%
function [algoParams] = FatCats_mask_generation(algoParams)
%-------------------------
complex_image = algoParams.complex4mask;
matrix_size = size(complex_image);
if length(matrix_size) == 2
matrix_size(3) = 1;
end
noise_slice = NoiseEstimation(complex_image);
%noise_slice
%pause
%-------------------------
   algoParams.mask4unwrap = zeros(matrix_size(1),matrix_size(2),matrix_size(3));
   algoParams.mask4supp = zeros(matrix_size(1),matrix_size(2),matrix_size(3));
   algoParams.mask4STAS = zeros(matrix_size(1),matrix_size(2),matrix_size(3));
   for index_slice = 1:matrix_size(3)
   complex_tmp(:,:) = complex_image(:,:,index_slice);  
   background_noise = noise_slice(index_slice);    
   %--------------------------------------
   [mask_outpout] = generate_mask(complex_tmp, background_noise,algoParams.th4unwrap);
   algoParams.mask4unwrap(:,:,index_slice) = mask_outpout;
   %
   [mask_outpout] = generate_mask(complex_tmp, background_noise,algoParams.th4supp);
   algoParams.mask4supp(:,:,index_slice) = mask_outpout;   
   %
   [mask_outpout] = generate_mask(complex_tmp, background_noise,algoParams.th4STAS);
   algoParams.mask4STAS(:,:,index_slice) = mask_outpout;   
   %index_slice
   %pause
   end
%
%
function [th4noise] = NoiseEstimation(complex_image)
%
%-------------------------
   matrix_size = size(complex_image);
   if length(matrix_size) == 2
   matrix_size(3) = 1;
   end
    %
   for index_slice = 1:matrix_size(3)   
   complex_tmp(:,:) = complex_image(:,:,index_slice);
   mag_original = abs(complex_tmp);
   mag_vec = mag_original(:);
   mag_vec(isnan(mag_vec)) = [];
   mag_vec_gray = mag_vec;
   [yy II] = sort(mag_vec_gray,'descend');
   mag_vec_gray(II(1:100)) = mag_vec_gray(II(100)); % remove intensity spikes
   mag_vec_gray = mat2gray(mag_vec_gray);
   mag_vec_gray_tmp = mag_vec_gray;
   mag_vec_gray_tmp(mag_vec_gray == 0) = [];
   clear yy;clear II;
   %
   xx = 0.18:0.02:1.0;
   [yy II] = hist(mag_vec_gray_tmp,xx);
   yy = yy./length(mag_vec_gray_tmp);
   %plot(xx,yy,'o-r');
   yy(1) = [];   
   %
    if sum(abs(diff(yy)).*yy(1:(length(yy)-1))) > 0.001 
        mag_vec(mag_vec_gray > 0.1) = []; % more homogeneity
        mag_vec(mag_vec == 0) = [];
        th4noise(index_slice) = std(mag_vec);
    else
        mag_vec(mag_vec_gray > 0.05) = []; % less homogeneity
        mag_vec(mag_vec == 0) = [];
        th4noise(index_slice) = std(mag_vec);   
    end 
   end
 %----------------------------------------------------------------------
function [mask_outpout] = generate_mask(complex_tmp, background_noise,th4mask)
   H = fspecial('gaussian',3);    
   complex_tmp = imfilter(complex_tmp,H);
   complex_tmp(isnan(complex_tmp)) = 0;
   mag_original = abs(complex_tmp);
   matrix_size = size(complex_tmp);
   mask_outpout = ones(matrix_size(1),matrix_size(2));
   mask_outpout(mag_original < background_noise*th4mask) = 0;
   [L_0] = bwlabel(mask_outpout,4);
   mask_outpout(L_0 == 0) = 0;
