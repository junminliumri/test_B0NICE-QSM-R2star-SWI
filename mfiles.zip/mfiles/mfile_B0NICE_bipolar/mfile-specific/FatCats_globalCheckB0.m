%
function [algoParams] = FatCats_globalCheckB0(algoParams)
pi_2 = 2*pi; 
%
complex_image = algoParams.complex_image;
%mask4STAS = algoParams.mask4STAS;
%index_echo = algoParams.index4pair;
%pause
%delta_PhaseEcho = algoParams.theory_Phase4pair;
%
TEratio = round(algoParams.delta_TE4B0/(algoParams.TE_seq(2)-algoParams.TE_seq(1)));
index_shift = -(TEratio-1):(TEratio-1);
if length(index_shift) == 1
index_shift = [-1 0 1];
end
index_shift(index_shift == 0) = [];
index_shift = [0 index_shift];
algoParams.index_shift = index_shift;
%-----
%if check_step == 1
%clear index_shift;
%index_shift = 0;
%end
%
%-------------------------
matrix_size = algoParams.matrix_size;
%
%-------------------------
B0_map_ori = algoParams.B0_map_raw;
for index_ss = 1:length(index_shift)
    B0_map_shift(:,:,:,index_ss) = B0_map_ori + index_shift(index_ss)*algoParams.error_2pi;
end
%
complex_HP = zeros(matrix_size(1),matrix_size(2),matrix_size(3),matrix_size(5));
phase_diff = zeros(matrix_size(1),matrix_size(2),matrix_size(3),matrix_size(5));
PhaseDiff_ss = zeros(matrix_size(1),matrix_size(2),matrix_size(3),length(index_shift));
for index_ss = 1:length(index_shift)
    if matrix_size(5) > 2
        for index_echo = matrix_size(5):-1:1
        complex_HP(:,:,:,index_echo) = complex_image(:,:,:,1,index_echo).*conj(complex_image(:,:,:,1,1));
        complex_HP(:,:,:,index_echo) = complex_HP(:,:,:,index_echo).*exp(-1i*B0_map_shift(:,:,:,index_ss)*(algoParams.TE_seq(index_echo)-algoParams.TE_seq(1)));
        phase_diff(:,:,:,index_echo) = angle(complex_HP(:,:,:,index_echo).*conj(algoParams.complexFromFF(:,:,:,index_echo)));
        phase_diff(isnan(phase_diff)) = 0;
        %figure(1)
        %subplot(2,2,1);imagesc(angle(algoParams.complexFromFF(:,:,index_slice,index_echo)),[-pi pi]);colormap gray;
        %subplot(2,2,2);imagesc(angle(complex_HP),[-pi pi]);colormap gray;
        %subplot(2,2,3);imagesc(algoParams.FF_raw_mean(:,:,index_slice),[0 1]);colormap gray;
        %subplot(2,2,4);imagesc(phase_diff,[-pi pi]);colormap gray;
        %index_echo
        %index_slice
        %index_ss
        %pause
        end
    else
        index_echo = 2;
        complex_HP(:,:,:,index_echo) = complex_image(:,:,:,1,index_echo).*conj(complex_image(:,:,:,1,1));
        complex_HP(:,:,:,index_echo) = complex_HP(:,:,:,index_echo).*exp(-1i*B0_map_shift(:,:,:,index_ss)*(algoParams.TE_seq(index_echo)-algoParams.TE_seq(1)));
        phase_diff(:,:,:,index_echo) = angle(complex_HP(:,:,:,index_echo).*conj(algoParams.complexFromFF(:,:,:,index_echo)));
        phase_diff(isnan(phase_diff)) = 0;
        phase_diff(:,:,:,index_echo) = phase_diff(:,:,:,index_echo).*(1-algoParams.FF_raw_mean);
        %figure(1)
        %subplot(2,2,1);imagesc(angle(algoParams.complexFromFF(:,:,index_slice,index_echo)),[-pi pi]);colormap gray;
        %subplot(2,2,2);imagesc(angle(complex_HP),[-pi pi]);colormap gray;
        %subplot(2,2,3);imagesc(algoParams.FF_raw_mean(:,:,index_slice),[0 1]);colormap gray;
        %subplot(2,2,4);imagesc(phase_diff,[-pi pi]);colormap gray;
        %index_echo
        %index_slice
        %index_ss
        %pause
       
    end
    PhaseDiff_ss(:,:,:,index_ss) = sum(abs(phase_diff),4);
    %imshow3D(PhaseDiff_ss(:,:,:,index_ss));colormap gray;
    %index_ss
    %pause
end


if algoParams.unwrap_mode == 3
        for index_ss = 1:length(index_shift)
        diff_3D(:,:,:) = PhaseDiff_ss(:,:,:,index_ss);
        diff_3D(isnan(diff_3D)) = 0;
        %figure(1)
        %subplot(2,2,1);imagesc(angle(algoParams.complexFromFF(:,:,index_slice,index_echo)),[-pi pi]);colormap gray;
        %subplot(2,2,2);imagesc(angle(complex_HP),[-pi pi]);colormap gray;
        %subplot(2,2,3);imagesc(algoParams.FF_raw_mean(:,:,index_slice),[0 1]);colormap gray;
        %subplot(2,2,4);imagesc(phase_diff,[-pi pi]);colormap gray;
        %index_echo
        %index_slice
        %index_ss
        %pause
        sum_vec(index_ss) = sum(abs(diff_3D(:)));
        end
        %sum_vec
        sum_min = min(sum_vec);
        index_min = find(sum_vec == sum_min);
        index_ss_min = index_min(1);
        if length(index_min) == 2 && abs(index_shift(index_min(1))) > abs(index_shift(index_min(2)))
        index_ss_min = index_min(2);
        end
        %index_ss_min
        %algoParams.index_ss_min(index_slice) = index_ss_min;
        B0_map_ori(:,:,:) = B0_map_shift(:,:,:,index_ss_min);
        %pause
else
    for index_slice = 1:matrix_size(3)    
        for index_ss = 1:length(index_shift)
        diff_slice(:,:) = PhaseDiff_ss(:,:,index_slice,index_ss);
        diff_slice(isnan(diff_slice)) = 0;
        %figure(1)
        %subplot(2,2,1);imagesc(angle(algoParams.complexFromFF(:,:,index_slice,index_echo)),[-pi pi]);colormap gray;
        %subplot(2,2,2);imagesc(angle(complex_HP),[-pi pi]);colormap gray;
        %subplot(2,2,3);imagesc(algoParams.FF_raw_mean(:,:,index_slice),[0 1]);colormap gray;
        %subplot(2,2,4);imagesc(phase_diff,[-pi pi]);colormap gray;
        %index_echo
        %index_slice
        %index_ss
        %pause
        sum_vec(index_ss) = sum(abs(diff_slice(:)));
        end
        %sum_vec
        sum_min = min(sum_vec);
        index_min = find(sum_vec == sum_min);
        index_ss_min = index_min(1);
        if length(index_min) == 2 && abs(index_shift(index_min(1))) > abs(index_shift(index_min(2)))
        index_ss_min = index_min(2);
        end
        %index_ss_min
        algoParams.index_ss_min(index_slice) = index_ss_min;
        B0_map_ori(:,:,index_slice) = B0_map_shift(:,:,index_slice,index_ss_min);
        %pause
    end
end
%
algoParams.B0_map_raw = B0_map_ori;
%-------------------------

