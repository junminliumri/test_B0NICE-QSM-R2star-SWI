function [ newImages ] = FixB0map_UsingFilling( algoParams )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
pi_2 = 2*pi;
originalImages = algoParams.B0_map_raw;
%originalImages = originalImages.*algoParams.delta_TE4B0;
mask4bad = algoParams.BW_label;
%
matrix_size = size(originalImages);
if length(matrix_size) == 2
matrix_size(3) = 1;
end
%
newImages = originalImages;
%create a big gaussian and an averaging kernal to use
G = fspecial('gaussian',[1 1]*7,3);
H = fspecial('average',[5 5]);
%
for index_slice = 1:matrix_size(3)
badPixels(:,:) = zeros(matrix_size(1:2));
badPixels(:,:) = mask4bad(:,:,index_slice);
badPixels = imdilate(badPixels,ones(1));
original_slice(:,:) = originalImages(:,:,index_slice);
%
new_slice = imfilter(original_slice,G,'replicate','same');
new_slice(~badPixels) = original_slice(~badPixels);
%original_slice(badPixels == 1) = original_slice(badPixels == 1)...
%                                - pi_2*round((original_slice(badPixels==1) - new_slice(badPixels==1))./pi_2);
% now average to
for index_loop = 1:10
new_slice = imfilter(new_slice,H,'replicate','same');
new_slice(~badPixels) = original_slice(~badPixels);
end
%
new_slice(badPixels == 1) = original_slice(badPixels == 1)...
                                - pi_2*round((original_slice(badPixels==1) - new_slice(badPixels==1))./pi_2);
%
new_slice(1,:) = original_slice(2,:);
new_slice(matrix_size(1),:) = original_slice((matrix_size(1)-1),:);
new_slice(:,1) = original_slice(:,2);
new_slice(:,matrix_size(2)) = original_slice(:,(matrix_size(2)-1));
%
%imagesc(new_slice);axis square;
%index_slice
%pause
newImages(:,:,index_slice) = new_slice;%./algoParams.delta_TE4B0;
end
%
end

