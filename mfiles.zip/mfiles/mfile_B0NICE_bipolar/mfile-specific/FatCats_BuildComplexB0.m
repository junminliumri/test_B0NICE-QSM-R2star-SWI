%
function [algoParams] = FatCats_BuildComplexB0(algoParams)
%
%
TE_seq = algoParams.TE_seq;
complex_image = algoParams.complex_image;
complex_image(isnan(complex_image)) = 1;
matrix_size = algoParams.matrix_size;
flag_B0 = algoParams.index_B0(1);
index_start = algoParams.index_B0(2);
index_end = algoParams.index_B0(3);
%
if algoParams.FiltSize > 1
H = fspecial('average',[algoParams.FiltSize algoParams.FiltSize]);
end
    complex_B0 = zeros(matrix_size(1),matrix_size(2),matrix_size(3));
    %
    if flag_B0 == 1
        for index_slice = 1:matrix_size(3)
        complex_0 = complex_image(:,:,index_slice,1,index_start);
        complex_1 = complex_image(:,:,index_slice,1,index_end);   
        complex_tmp = complex_1.*conj(complex_0);
        %complex_tmp = complex_tmp./abs(complex_tmp);
        complex_tmp(isnan(complex_tmp)) = 1;
        
        if algoParams.FiltSize > 1
        LPF = imfilter(complex_tmp,H);
        else
        LPF = complex_tmp;   
        end
        %[LPF] = LPF_B0(complex_tmp,32);
        complex_B0(:,:,index_slice) = LPF;
        end
    elseif flag_B0 == 2
        for index_slice = 1:matrix_size(3)   
        complex_0 = complex_image(:,:,index_slice,1,index_start);
        complex_1 = complex_image(:,:,index_slice,1,index_start+1); 
        complex_2 = complex_image(:,:,index_slice,1,index_end);
        complex_10(:,:) = complex_1.*conj(complex_2);
        complex_20(:,:) = complex_0.*conj(complex_2);
        complex_tmp = conj(complex_10.*complex_20);
        clear complex_10;
        clear complex_20;
        clear complex_0;
        clear complex_1;
        clear complex_2;
        complex_tmp(isnan(complex_tmp)) = 1;
        complex_B0(:,:,index_slice) = complex_tmp;
        end
    elseif flag_B0 ==3
        for index_slice = 1:matrix_size(3)
        complex_0(:,:) = complex_image(:,:,index_slice,1,index_start);
        complex_1(:,:) = complex_image(:,:,index_slice,1,index_end);   
        complex_tmp = complex_1.*conj(complex_0);
        complex_tmp = exp(1i*angle(complex_tmp));
        complex_tmp = complex_tmp.^2;
        %complex_tmp = imfilter(complex_tmp,H);
        phase_tmp = angle(complex_tmp);
        complex_tmp = abs(complex_1).*exp(1i*phase_tmp);
        complex_tmp = imfilter(complex_tmp,H);
        complex_tmp(isnan(complex_tmp)) = 1;
        %[LPF] = LPF_B0(complex_tmp,32);
        complex_B0(:,:,index_slice) = complex_tmp;
        end
    end
    
    if flag_B0 ~= 3
    phase_B0 = angle(complex_B0); 
    complex_B0 = exp(1i*phase_B0).*abs(complex_image(:,:,:,1,index_start));
    end
    algoParams.complex_B0 = complex_B0;
        
