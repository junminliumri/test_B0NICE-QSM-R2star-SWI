%
function [algoParams] = FatCats_BW_label_edge(algoParams)
%
pi_2 = 2*pi;
%
B0_map = algoParams.B0_map_raw;
%-------------------------
th4label = algoParams.th4label;
%-------------------------
clear algoParams.BW_label;
diff_step = algoParams.diff_step;       
for index_slice = 1:algoParams.matrix_size(3)
    %---------------------------
    mask_x = zeros(algoParams.matrix_size(1:2));
    mask_y = zeros(algoParams.matrix_size(1:2));
    %---------------------------
    B0_unit(:,:) = B0_map(:,:,index_slice);
    diff_x = diff(B0_unit,diff_step,1);
    diff_x(abs(diff_x) >= th4label) = 1;
    diff_x(abs(diff_x) ~= 1) = 0;
    %----------------------------
    %diff_x = imerode(diff_x,se);
    mask_x((diff_step):(algoParams.matrix_size(1)-1),:) = diff_x;
    %mask_x(1,:) = 0;
    mask_x((algoParams.matrix_size(1)-1),:) = 0;
    %----------------------------    
    diff_y = diff(B0_unit,diff_step,2);
    diff_y(abs(diff_y) >= th4label) = 1;
    diff_y(abs(diff_y) ~= 1) = 0;
    %----------------------------
    %diff_y = imerode(diff_y,se);
    mask_y(:,(diff_step+0):(algoParams.matrix_size(2)-1)) = diff_y;
    %mask_y(:,1) = 0;
    mask_y(:,(algoParams.matrix_size(2)-1)) = 0;
    %----------------------------
    mask_xy = mask_x + mask_y;
    mask_xy(mask_xy > 0) = 1;
    mask_xy(algoParams.mask4supp(:,:,index_slice) == 0) = 0;
    %
    BW_label(:,:,index_slice) = mask_xy;
    %
    if algoParams.debug == 1
    figure(8)
    subplot(1,algoParams.matrix_size(3),index_slice);imagesc(BW_label(:,:,index_slice),[0 1]);axis square;axis off;
    figure(9)
    %subplot(1,3,2);imagesc(algoParams.FF_bin(:,:,index_slice));axis square;axis off; 
    subplot(1,algoParams.matrix_size(3),index_slice);imagesc(algoParams.B0_map_raw(:,:,index_slice));axis square;axis off;     
    index_slice
    pause
    end
    %
end
algoParams.BW_label = BW_label;
%

%
