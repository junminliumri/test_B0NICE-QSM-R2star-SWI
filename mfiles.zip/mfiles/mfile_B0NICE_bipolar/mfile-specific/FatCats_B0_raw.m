%
function [algoParams] = FatCats_B0_raw(algoParams)
%
%
%pi_2 = 2*pi;
matrix_size = algoParams.matrix_size;
%

        complex_B0 = algoParams.complex_B0;
        %
        [unwrap_phase] = PUROR2D(complex_B0,algoParams.mask4unwrap,algoParams.mask4supp,algoParams.mask4STAS);       
        unwrap_phase(isnan(unwrap_phase)) = 0;
        [ unwrap_phase unwrap_phase_tmp] = StackSlice_Igor(unwrap_phase, unwrap_phase, algoParams.mask4STAS);
        %-----------------------------------------
        if algoParams.unwrap_mode == 3
        debug_PUROR = 0;
        [ unwrap_phase ] = PUROR3D( unwrap_phase, complex_B0,algoParams.mask4unwrap, algoParams.mask4supp, algoParams.mask4STAS, debug_PUROR ); 
        end
        %--------------------------------------
        %imshow3Dfull(unwrap_phase,[-20 20]);colormap gray;
        %pause
        %-----------------------------------------
        if algoParams.upSampling > 1
        algoParams.B0_map_raw = resize(unwrap_phase,[matrix_size(1) matrix_size(2) matrix_size(3)]);
        else
         algoParams.B0_map_raw = unwrap_phase;   
        end
%
%
