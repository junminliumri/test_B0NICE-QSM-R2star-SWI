%
function [algoParams] = FatCats_defineRegion_usingPhaseGradient(algoParams)
%
%
B0_map = algoParams.B0_map_raw;
%-------------------------
th4label = algoParams.th4label;
%-------------------------
clear algoParams.BW_label;
diff_step = algoParams.diff_step;
    se = strel('disk',2);        
for index_slice = 1:algoParams.matrix_size(3)
    %---------------------------
    mask_x = zeros(algoParams.matrix_size(1:2));
    mask_y = zeros(algoParams.matrix_size(1:2));
    %---------------------------
    B0_unit(:,:) = B0_map(:,:,index_slice);
    diff_x = diff(B0_unit,diff_step,1);
    diff_x(abs(diff_x) < th4label) = 1;
    diff_x(abs(diff_x) ~= 1) = 0;
    %----------------------------
    diff_x = imerode(diff_x,se);
    mask_x((diff_step + 0):(algoParams.matrix_size(1)-1),:) = diff_x;
    %----------------------------    
    diff_y = diff(B0_unit,diff_step,2);
    diff_y(abs(diff_y) < th4label) = 1;
    diff_y(abs(diff_y) ~= 1) = 0;
    %----------------------------
    diff_y = imerode(diff_y,se);
    mask_y(:,(diff_step + 0):(algoParams.matrix_size(2)-1)) = diff_y;
    %----------------------------
    mask_xy = mask_x.*mask_y;
    %figure(7)   
    %subplot(1,2,1);imagesc(mask_xy,[0 1]);axis square;axis off;    
    %subplot(1,2,2);imagesc(B0_unit);axis square;axis off;
    %
    [L, num] = bwlabel(mask_xy, 4);   
    %subplot(1,2,2);imagesc(L);axis square;axis off;

    s  = regionprops(L, 'area');
    [y_area I_area] = sort([s.Area],'descend');
    %y_area(1:5)
    %I_area(1:5)
    %
    y_area(y_area <algoParams.minAreaUsingPhaseGradient) = [];
    %y_area()
    %
    BW_L_tmp = zeros(algoParams.matrix_size(1:2));
    for index_L = 1:length(y_area)
        BW_tmp = zeros(algoParams.matrix_size(1:2));
        BW_tmp(L == I_area(index_L)) = 1;
        %
        BW_tmp = imdilate(BW_tmp,se);
        %--------
        %BW_tmp(mask_xy == 0) = 1;
        %[L_tt, num_tt] = bwlabel(BW_tmp, 4);
        %s_tt  = regionprops(L_tt, 'area');
        %[y_area_tt I_area_tt] = sort([s_tt.Area],'descend');
        %BW_tmp = zeros(algoParams.matrix_size(1:2));
        %BW_tmp(L_tt == I_area_tt(1)) = 1;
        %mask_xy(BW_tmp == 1) = 1;
        %imagesc(BW_tmp);axis square;axis off;
        %index_L
        %pause
        %-------
        BW_L_tmp(BW_tmp == 1) = index_L;
    end
    %
    BW_L_tmp = imdilate(BW_L_tmp,se);
    BW_label(:,:,index_slice) = BW_L_tmp;
    %
    if algoParams.debug == 1
    figure(8)
    imagesc(BW_label(:,:,index_slice),[0 5]);axis square;axis off;
    figure(9)
    %subplot(1,3,2);imagesc(algoParams.FF_bin(:,:,index_slice));axis square;axis off; 
    imagesc(algoParams.B0_map_raw(:,:,index_slice));axis square;axis off;     
    index_slice
    pause
    end
    %
end
algoParams.BW_label = BW_label;
%

%
