%
function [algoParams] = FatCats_B0Raw_Phase2Freq(algoParams)
%
%
TE_seq = algoParams.TE_seq;
matrix_size = algoParams.matrix_size;
flag_B0 = algoParams.index_B0(1);
index_start = algoParams.index_B0(2);
index_end = algoParams.index_B0(3);
%
unwrap_phase = algoParams.B0_map_raw;

    if flag_B0 == 1    
        B0_map = unwrap_phase./(TE_seq(index_end) - TE_seq(index_start));
    % 
    elseif flag_B0 == 2
      
        B0_map = unwrap_phase./(TE_seq(index_end)+ TE_seq(index_start+1)- 2*TE_seq(index_start)); 
    elseif flag_B0 == 3
        
        B0_map = unwrap_phase./((TE_seq(index_end)- TE_seq(index_start))*2); 
    end
    %
    B0_map(isnan(B0_map)) = 0;
    algoParams.B0_map_raw = B0_map;
%
%
