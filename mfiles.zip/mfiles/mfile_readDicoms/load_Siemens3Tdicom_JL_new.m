%
function [] = load_Siemens3Tdicom_JL_new(name4mat,mag_name,phase_name)

%currentfolder = pwd;
%filelist = dirPlus(currentfolder, 'FileFilter', '\.dcm$','PrependPath', false);

%
%filelist = dir;

%
%tf = ismember( {filelist.name}, {'.', '..'});
%filelist(tf) = [];  %remove current and parent directory.
%filename = filelist(1);
%info = dicominfo(filename{:});
info = dicominfo(['IM-',mag_name,'-0001.dcm']);

matrix_size(1) = single(info.Width);
matrix_size(2) = single(info.Height);

matrix_size(3) = 1;

siemens_struct = SiemensInfo(info);
voxel_size(1) = single(info.PixelSpacing(1));
voxel_size(2) = single(info.PixelSpacing(2));
voxel_size(3) = single(info.SliceThickness);

CF = info.ImagingFrequency *1e6;
%Echo train length
total_echo = info.EchoTrainLength;

total_slice = siemens_struct.sKSpace.lImagesPerSlab;

minSlice = 1e10;
maxSlice = -1e10;
for ee = 1:total_echo
    for ss = 1:total_slice
        ii = ss + (ee-1)*total_slice;
    if ii < 10
    mag_dicom = ['IM-',mag_name,'-000',int2str(ii),'.dcm']; 
    phase_dicom = ['IM-',phase_name,'-000',int2str(ii),'.dcm'];
    elseif ii < 100
    mag_dicom = ['IM-',mag_name,'-00',int2str(ii),'.dcm']; 
    phase_dicom = ['IM-',phase_name,'-00',int2str(ii),'.dcm'];
    elseif ii < 1000
    mag_dicom = ['IM-',mag_name,'-0',int2str(ii),'.dcm']; 
    phase_dicom = ['IM-',phase_name,'-0',int2str(ii),'.dcm'];    
    else
    mag_dicom = ['IM-',mag_name,'-',int2str(ii),'.dcm']; 
    phase_dicom = ['IM-',phase_name,'-',int2str(ii),'.dcm'];           
    end
    mag_info2 = get_dcm_tags(mag_dicom);
    phase_info2 = get_dcm_tags(phase_dicom);
    %-----------------------------
    if mag_info2.SliceLocation<minSlice
        minSlice = mag_info2.SliceLocation;
        minLoc = mag_info2.ImagePositionPatient;
    end
    if mag_info2.SliceLocation>maxSlice
        maxSlice = mag_info2.SliceLocation;
        maxLoc = mag_info2.ImagePositionPatient;
    end
    %-----------------------------
    mag = double(dicomread(mag_dicom));
    phase = double(dicomread(phase_dicom));

    phase  = (phase*phase_info2.RescaleSlope + phase_info2.RescaleIntercept)/single(max(phase(:)))*pi;
    %phase = (phase - 2048)*pi/2048;
    
    %figure(1)
    %subplot(1,2,1);imagesc(mag);colormap gray;
    %subplot(1,2,2);imagesc(phase,[-pi pi]);colormap gray;
    %ee
    %ss
    %pause
    complex_image(:,:,ss,1,ee) = mag.*exp(1i*phase);
    end
end
%
%complex_image = permute(complex_image,[2 1 3 4 5]);%This is because the first dimension is row in DICOM but COLUMN in MATLAB
%
matrix_size(3) = round(norm(maxLoc - minLoc)/voxel_size(3))+1 ;

Affine2D = reshape(info.ImageOrientationPatient,[3 2]);
Affine3D = [Affine2D (maxLoc-minLoc)/( (matrix_size(3)-1)*voxel_size(3))];
B0_dir = Affine3D\[0 0 1]';
B0_dir = B0_dir';
B0_dir = [B0_dir(2) B0_dir(1) B0_dir(3)]; % seems need it
%
imDataParams.FieldStrength = siemens_struct.sProtConsistencyInfo.flNominalB0; 

imDataParams.PrecessionIsClockwise = info.MagneticFieldStrength*info.ImagingFrequency>0; %T
imDataParams.TE = siemens_struct.alTE(1:total_echo)/1e6;
imDataParams.images = complex_image;
imDataParams.B0_dir = B0_dir;
imDataParams.voxel_size = voxel_size;
imDataParams.CF = CF;
%
save(name4mat,'imDataParams');
%
function info = get_dcm_tags(filename)
attrs=dicomattrs(filename);
for t={'SliceLocation','ImagePositionPatient',...
        'EchoTime','EchoNumber','ImageType','RescaleSlope','RescaleIntercept'}
    t=char(t);
    [gr, el] = dicomlookup(t);
    if ~strcmp(t,'ImageType')
        for i=1:length(attrs);
            if (attrs(i).Group==gr)&&(attrs(i).Element==el)
                eval(['info.' t '= sscanf(char(attrs(i).Data), ''%f\\'');'])
                break;
            end
        end
    else
        for i=1:length(attrs);
            if (attrs(i).Group==gr)&&(attrs(i).Element==el)
                info.ImageType = char(attrs(i).Data);
            end
        end
    end
end