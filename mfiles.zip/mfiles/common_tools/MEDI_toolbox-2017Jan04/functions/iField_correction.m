% Correction of the iField - removal of the echo-dependent linear phase
%   gradient to avoid non-2pi wrap-like artifacts in iFreq_raw 
%
%   [iField_corrected] = iField_correction(iField,voxel_size)
% 
%   output
%   iField_corrected - iField with echo-dependent linear gradient
%   removed from the phase
%
%   input
%   iField - the complex MR image
%   voxel_size - the size of a voxel
%
%   Created by Alexey V. Dimov and Pascal Spincemaille in 2017.01.11

function [iField_corrected] = iField_correction(iField,voxel_size)
matrix_size = size(squeeze(iField(:,:,:,1)));
Mask = genMask(iField,voxel_size);
pha = angle(iField);
mag = sqrt(sum(abs(iField).^2,4));
%Quick and dirty echo-by-echo unwrapping
for i = 1 : size(iField,4)
    pha(:,:,:,i) = unwrapPhase(mag,squeeze(pha(:,:,:,i)),matrix_size);
end
%Laplacian in echo direction
echo_laplacian = zeros([matrix_size, size(iField,4)-2]);
for i = 1 : size(echo_laplacian,4)
    echo_laplacian(:,:,:,i) = pha(:,:,:,i) - 2*pha(:,:,:,i+1) + pha(:,:,:,i+2);
end
%Determine direction of phase correction gradient 
GRADDIR = enc_dir(echo_laplacian,Mask);
%Estimate parameters of the gradient
[slope, intercept] = fit_grad(cat(4, pha(:,:,:,2) - pha(:,:,:,1), echo_laplacian), Mask, GRADDIR);
%Subtract artificially added phase
phasor = phasor_prep(slope, intercept, matrix_size, GRADDIR);
iField_corrected = iField.*exp(-1i*phasor);
end