function enc_dir = enc_dir(echo_laplacian,Mask)
    enc_dir = 1;
    g1 = 0;
    g2 = 0;
    
    d1 = max(max(Mask,[],2),[],3);
    d1first = find(d1,1,'first');
    d1last = find(d1,1,'last');

    d2 = max(max(Mask,[],1),[],3);
    d2first = find(d2,1,'first');
    d2last = find(d2,1,'last');
    
    for jj = 1 : size(echo_laplacian,4)

    ind = zeros(sum(Mask(:)),1);
    val = zeros(sum(Mask(:)),1);
    k = 1;
    for i = d1first : d1last
        A = squeeze(echo_laplacian(i,:,:,jj));
        B = squeeze(Mask(i,:,:));
        ind(k:k+sum(B(:))-1) = i;
        val(k:k+sum(B(:))-1) = A(B>0);
        k = k+sum(B(:));
    end
    X = [ind ones(length(ind),1)];
    b1 = X\val;
    if abs(b1(1)) > g1
        g1 = abs(b1(1));
    end
    
    k = 1;
    for i = d2first : d2last
        A = squeeze(echo_laplacian(:,i,:,jj));
        B = squeeze(Mask(:,i,:));
        ind(k:k+sum(B(:))-1) = i;
        val(k:k+sum(B(:))-1) = A(B>0);
        k = k+sum(B(:));
    end
    X = [ind ones(length(ind),1)];
    b2 = X\val;
    if abs(b2(1)) > g2
        g2 = abs(b2(1));
    end
    end
    if g2 > g1
        enc_dir = 2;
    end
end