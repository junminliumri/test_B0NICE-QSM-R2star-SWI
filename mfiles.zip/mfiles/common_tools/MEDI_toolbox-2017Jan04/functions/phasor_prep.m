function phasor = phasor_prep(slope, intercept, matrix_size, GRADDIR)
    phasor = zeros(matrix_size);
    if GRADDIR == 1
        for i = 1 : matrix_size(1)
            phasor(i,:,:) = i;
        end
    else
        for i = 1 : matrix_size(2)
            phasor(:,i,:) = i;
        end
    end
    phasor = repmat(phasor, [1 1 1 length(slope)]);
    for i = 1 : size(phasor,4)
        phasor(:,:,:,i) = phasor(:,:,:,i)*slope(i)+intercept(i);
    end
end