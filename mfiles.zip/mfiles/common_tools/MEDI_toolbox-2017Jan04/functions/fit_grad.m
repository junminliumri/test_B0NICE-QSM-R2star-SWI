function [slope, intercept]  = fit_grad(echo_laplacian,Mask,dir)
sl = zeros(size(echo_laplacian,4)+1, 1);
in = zeros(size(echo_laplacian,4)+1, 1);

for k = 1 : size(echo_laplacian,4)
    ind = zeros(sum(Mask(:)),1);
    val = zeros(sum(Mask(:)),1);
    if dir == 1
        l = 1;
        d1 = max(max(Mask,[],2),[],3);
        d1first = find(d1,1,'first');
        d1last = find(d1,1,'last');
        for i = d1first : d1last
            A = squeeze(echo_laplacian(i,:,:,k));
            B = squeeze(Mask(i,:,:));
            ind(l:l+sum(B(:))-1) = i;
            val(l:l+sum(B(:))-1) = A(B>0);
            l = l+sum(B(:));
        end
        X = [ind ones(length(ind),1)];
        b1 = X\val;
        sl(k+1) = b1(1);
        in(k+1) = b1(2);
    else
        l = 1;
        d2 = max(max(Mask,[],1),[],3);
        d2first = find(d2,1,'first');
        d2last = find(d2,1,'last');
        for i = d2first : d2last
            A = squeeze(echo_laplacian(:,i,:,k));
            B = squeeze(Mask(:,i,:));
            ind(l:l+sum(B(:))-1) = i;
            val(l:l+sum(B(:))-1) = A(B>0);
            l = l+sum(B(:));
        end
        X = [ind ones(length(ind),1)];
        b1 = X\val;
        sl(k+1) = b1(1);
        in(k+1) = b1(2);
    end    
end
Ainv = zeros(size(echo_laplacian,4)+1);
Ainv(:,1) = ones(size(Ainv(:,1)));
for j = 2 : size(Ainv,2)
    Ainv(j:end,j) = [1:1:length(Ainv(j:end,j))];
end
slope = Ainv*sl;
intercept = Ainv*in;
end