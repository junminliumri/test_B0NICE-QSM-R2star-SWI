% This is an updated version of MEDI toolbox.
% 
Minor corrections to the previously published code

Please contact qsmreconstruction@gmail.com with your questions and
suggestion

Regards,
Cornell MRI lab