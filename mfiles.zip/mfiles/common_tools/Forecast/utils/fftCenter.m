function [c] = fftCenter (N)
% Calculates the index of k_0 for a dimension of size N

c = floor(N/2) + 1;

end

