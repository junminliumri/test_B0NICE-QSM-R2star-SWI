function [kspaceSamplingTimes] = calculateCartesianSamplingTimes (matrixSize, readoutDimension, echoTime, readoutInterval)

% Function to calculate the time after excitation when k-space locations
% are sampled for linear Cartesian readouts.
%
% Input:
% matrixSize: [X Y Z] size of the k-space matrix
% readoutDimension: 'x' or 'y' or 'z' dimension along which the readout is performed
% echoTime: Echo time in milliseconds
% readoutInterval: Length of the readout interval in milliseconds
%
% Output:
% kspaceSamplingTimes: Matrix of sampling times for k-space location

%% Add utils to search path
addpath(fullfile(fileparts(mfilename('fullpath')), 'utils'));

if (strcmpi(readoutDimension, 'x'))
    fc = fftCenter(matrixSize(1));
    kspaceSamplingTimes = repmat((-fc:-fc+matrixSize(1)-1)/fc, [matrixSize(2) 1 matrixSize(3)]);
elseif (strcmpi(readoutDimension, 'y'))
    fc = fftCenter(matrixSize(2));
    kspaceSamplingTimes = repmat(permute((-fc:-fc+matrixSize(2)-1)/fc,[2 1]), [1 matrixSize(1) matrixSize(3)]);
elseif (strcmpi(readoutDimension, 'z'))
    fc = fftCenter(matrixSize(3));
    kspaceSamplingTimes = repmat(permute((-fc:-fc+matrixSize(3)-1)/fc,[1 3 2]), [matrixSize(2) matrixSize(1) 1]);
else
    error('Invalid dimension');
end

kspaceSamplingTimes = kspaceSamplingTimes * readoutInterval/2 + echoTime;

end
