FORECAST: Fourier-based Off-REsonanCe Artifact simulation in the STeady-state

FORECAST is a fast alternative to Bloch simulation for simulating
off-resonance effects in steady-state MRI. FORECAST accelerates simulation
of steady-state pulse sequences by using multiple Fast Fourier Transforms
to evaluate the signal equation, which can include proton density, T2, and
off-resonance effects. Currently the simulation is limited to Cartesian
gradient echo pulse sequences, but we plan to add support for Spin Echo and
non-Cartesian pulse sequences.


Getting started

Place the contents of the .zip file in a directory of your choice (for
example 'c:\Matlab\Forecast'). You can run the demo.m file to see if our
example simulations run properly. If you would like to use FORECAST from
other MATLAB scripts, add the FORECAST directory to your MATLAB path.


Usage examples

See demo.m and demo_brainweb.m for examples on how to use FORECAST.


Referring to FORECAST

If you use FORECAST in your research, please include a reference to our
ISMRM abstract and a link to the most recent code (a more complete article
on the method is in preparation):
F. Zijlstra, J.G. Bouwman, I. Braskute, and P.R. Seevinck, "Fast simulation
of off-resonance artifacts in MRI using FORECAST (Fourier-based
Off-REsonanCe Artifact Simulation in the STeady-State)", In: Proceedings of
the 24th Annual Meeting of ISMRM, Singapore, 2016


Contact

If you have any questions, suggestions, or find any bugs, feel free to
contact us.

Frank Zijlstra (f.zijlstra@gmail.com) and Job Bouwman (jgbouwman@hotmail.com), 2016
