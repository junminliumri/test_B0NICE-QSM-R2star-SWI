%
function [] = AdapComb_multiecho(matrix_size, name_chFile)
%
%imDataParams.FieldStrength = 3.0; % unit:T
%imDataParams.PrecessionIsClockwise = -1;
%imDataParams.TE = [3.204:1.464:9.10 16.75:7.15:46]./1000;% unit:s


%matrix_size = [256 256 50 32 10];
%
imDataParams.images = ones(matrix_size(1),matrix_size(2),matrix_size(3),1,matrix_size(5));
%
for index_echo = 1:matrix_size(5)
    for index_ch = 1:matrix_size(4)
    load([name_chFile,num2str(index_ch),'.mat']);
    complex_3D(:,:,:,index_ch,1) = complex_4D(:,:,:,index_echo);
    end
    clear complex_4D
    %
    for index_slice = 1:matrix_size(3)
    complex_slice(:,:,1,:,1) = complex_3D(:,:,index_slice,:,1);
    [sliceComb] = coilCombine(complex_slice);
    im_tmp(:,:) = sliceComb(:,:,1,1,1);
        if index_slice == 250%matrix_size(3)
        figure(1)
        subplot(1,2,1);imagesc(abs(im_tmp));
        subplot(1,2,2);imagesc(angle(im_tmp));
        index_slice
        pause
        end
    imDataParams.images(:,:,index_slice,1,index_echo) = sliceComb;
    end
end

%
save('33.mat','imDataParams');

%clear complex_3D