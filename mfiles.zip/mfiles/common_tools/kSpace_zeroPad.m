function [out] = kSpace_zeroPad (im, sz, value)
% Zero-pads matrix im to size sz, optionally with specified value
im_kSpace = ifftshift(ifftn(ifftshift(im)));
%im_kSpace = fftshift(im_kSpace);
%
if (nargin == 3)
    kSpace_out = value * ones(sz);
else
    kSpace_out = zeros(sz);
end

if (numel(sz) == 2)
    sz(3) = 1;
end

startX = fftCenter(sz(1)) - fftCenter(size(im_kSpace,1)) + 1;
startY = fftCenter(sz(2)) - fftCenter(size(im_kSpace,2)) + 1;
startZ = fftCenter(sz(3)) - fftCenter(size(im_kSpace,3)) + 1;

kSpace_out(startX:startX+size(im_kSpace,1)-1,startY:startY+size(im_kSpace,2)-1,startZ:startZ+size(im_kSpace,3)-1) = im_kSpace;
%kSpace_out = fftshift(kSpace_out);
out = fftshift(fftn(fftshift(kSpace_out)));

end
