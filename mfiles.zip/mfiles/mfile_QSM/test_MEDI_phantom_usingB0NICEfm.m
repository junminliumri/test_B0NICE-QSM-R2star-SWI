% test MEDI L1 using the phantom data
%
function [chi, RDF, Mask, iFreq] = test_MEDI_phantom_usingB0NICEfm(file4complexData, file4fm, flag_inphase)
%
load(file4complexData);
load(file4fm);
%
B0_dir = imDataParams.B0_dir;
CF = imDataParams.CF;
voxel_size = imDataParams.voxel_size;
%
imDataParams.images = conj(imDataParams.images);
%
if flag_inphase == 1
    complex_image = squeeze(imDataParams.images); 
    TE = imDataParams.TE;
    complex_image(:,:,:,1:2:3) = [];
    TE(1:2:3) = [];
    complex_image(:,:,:,2) = [];
    TE(2) = [];
else
    complex_image = squeeze(imDataParams.images); 
    TE = imDataParams.TE;
end   
clear imDataParams;
    
    ax_shift = [ 2 3 1];% the original volume is along [z x y], converting to [x y z]
    voxel_size = [voxel_size(ax_shift(1)) voxel_size(ax_shift(2)) voxel_size(ax_shift(3))];
    B0_dir = [B0_dir(ax_shift(1)) B0_dir(ax_shift(2)) B0_dir(ax_shift(3))];
    %stop
%    
delta_TE = TE(2) - TE(1);
[iFreq, N_std]=Fit_ppm_complex_TE(complex_image,TE);
iFreq = squeeze(abs(complex_image(:,:,:,1))).*exp(1i*iFreq);
%
iMag = squeeze(abs(complex_image(:,:,:,1))); clear complex_image;
[Mask] = genMask_fromMAG(iMag, voxel_size);
Mask(:,:,1:8) = 0; Mask(:,:,37:40) = 0; % remove the unreliable slices
%
    fm(isnan(fm)) = 0;
    [fm] = fm_polyfitting(fm,Mask,voxel_size, 6,0);
    fm2phase = 2*pi*delta_TE.*fm;
%
    iFreq = iFreq.*exp(-1i*fm2phase);
    %
    unwrap_mode = 3;
        [algoParams] = FatCats_SetAlgoParams4IEV_PUROR(iFreq, unwrap_mode);
        algoParams.complex4mask = iMag;
        [algoParams] = FatCats_unwrapPhaseUsingPUROR(algoParams);
        RDF = algoParams.unwrap_phase;%
        %
        %[base] = fm_polyfitting(RDF,Mask,voxel_size, 2,0);
        %RDF = RDF - base;
        clear algoParams;
    %
    RDF = permute(RDF,ax_shift);
    Mask = permute(Mask,ax_shift);
    iMag = permute(iMag,ax_shift);
    N_std = permute(N_std,ax_shift);
%
    %B0_dir = [0 0 1];
    lambda = 100;max_iter = 10;% important parameter, may need modified for different data sets
    [x, cost_reg_history, cost_data_history] = MEDI_L1_JL(iMag,RDF,N_std,Mask,voxel_size,B0_dir,lambda,max_iter);
    %
    for ii = 1:3
    index_tmp = find(ax_shift == ii);
    ax_shift_new(ii) =  index_tmp;
    end
    ax_shift = ax_shift_new; clear ax_shift_new;
   
    RDF = permute(RDF,ax_shift);
    Mask = permute(Mask,ax_shift);
    iMag = permute(iMag,ax_shift);
    N_std = permute(N_std,ax_shift);
    %
    for index_iter = 1:size(x,4)
    chi(:,:,:,index_iter) = permute(x(:,:,:,index_iter),ax_shift)./(2*pi*delta_TE*CF)*1e6;
    end
