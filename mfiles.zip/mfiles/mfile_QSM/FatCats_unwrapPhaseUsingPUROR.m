%
function [algoParams] = FatCats_unwrapPhaseUsingPUROR(algoParams)
%
%
pi_2 = 2*pi;

matrix_size = algoParams.matrix_size;
%

        complex_B0 = algoParams.complex_B0;
        %complex_B0 = flipdim(complex_B0,3);
        %complex_oriB0 = algoParams.complex_oriB0;
        %complex_oriB0 = flipdim(complex_oriB0,3);
        
        [algoParams] = FatCats_mask_generation(algoParams);
        
        [unwrap_phase] = PUROR2D(complex_B0,algoParams.mask4unwrap,algoParams.mask4supp,algoParams.mask4STAS);       
        
        phase_oriB0 = algoParams.phase_oriB0;
        
        [ unwrap_phase unwrap_phase_tmp] = StackSlice_Igor(unwrap_phase, unwrap_phase, algoParams.mask4STAS);
        %phase_oriB0 = flipdim(phase_oriB0,3);
        unwrap_phase = phase_oriB0 - pi_2*round((phase_oriB0 - unwrap_phase)./pi_2);
        %-----------------------------------------
        %-----------------------------------------
        if algoParams.unwrap_mode == 3
        debug_PUROR = 0;
        %
        [ unwrap_phase ] = PUROR3D( unwrap_phase,complex_B0,algoParams.mask4unwrap, algoParams.mask4supp, algoParams.mask4STAS, debug_PUROR ); 
        %algoParams.unwrap_phase_3D = unwrap_phase;
        %algoParams.unwrap_final = unwrap_phase;
        end
        %[ algoParams ] = Combine2D3D( algoParams );
        %unwrap_phase = algoParams.unwrap_final;

        %-----------------------------------------
        %unwrap_phase = flipdim(unwrap_phase,3);
        close all
        %imshow3D(unwrap_phase,[-8*pi 8*pi]);colormap gray;
        algoParams.unwrap_phase = unwrap_phase;
%
%
