% test MEDI L1 using the phantom data
%
function [chi, RDF, Mask, iFreq] = test_MEDI_head_usingB0NICEfm(file4complexData, file4fm, flag_inphase)
%
load(file4complexData);
load(file4fm);
%
%FieldStrength = imDataParams.FieldStrength;
CF = imDataParams.CF;
voxel_size = imDataParams.voxel_size;
B0_dir = imDataParams.B0_dir;
B0_dir_check = round(B0_dir).*[1 1 0];
if sum(B0_dir_check(:)) ~= 0
    fprintf('please check the slice orientation then set up ax_shift');
    %ax_shift = [3 1 2];
    %stop
end
%ax_shift = [2 1 3]; 
%
imDataParams.images = conj(imDataParams.images);
%
if flag_inphase == 1
    complex_image = squeeze(imDataParams.images); 
    TE = imDataParams.TE;
    complex_image(:,:,:,1:2:3) = [];
    TE(1:2:3) = [];
    complex_image(:,:,:,2) = [];
    TE(2) = [];
else
    complex_image = squeeze(imDataParams.images); 
    TE = imDataParams.TE;
end
clear imDataParams;
%
if sum(B0_dir_check(:)) ~= 0
voxel_size = [voxel_size(ax_shift(1)) voxel_size(ax_shift(2)) voxel_size(ax_shift(3))];
B0_dir = [B0_dir(ax_shift(1)) B0_dir(ax_shift(2)) B0_dir(ax_shift(3))];
%
complex_image = permute(complex_image,[ax_shift 4]);
fm = permute(fm,ax_shift);
end

delta_TE = TE(2) - TE(1);
[iFreq, N_std]=Fit_ppm_complex_TE(complex_image,TE);
iFreq = squeeze(abs(complex_image(:,:,:,1))).*exp(1i*iFreq);
%
clear complex_image;
%
upSampling = 1; % 1 no; >1 yes;
    if upSampling > 1
        ori_matrix = size(iFreq);
        [iFreq] = kSpace_zeroPad (iFreq, [ori_matrix(1) ori_matrix(2) ori_matrix(3)*upSampling]);
        N_std = resize(N_std, [ori_matrix(1) ori_matrix(2) ori_matrix(3)*upSampling]);
        fm = resize(fm, [ori_matrix(1) ori_matrix(2) ori_matrix(3)*upSampling]); 
        %
        voxel_size(3) = voxel_size(3)/upSampling;
        %
    end
        iMag = squeeze(abs(iFreq(:,:,:)));
        Mask4fitting = iMag>0.01*prctile(iMag(:),95);
        %Mask4fitting(:,:,(size(iMag,3)-4):(size(iMag,3))) = 0;Mask4fitting(:,:,1:3) = 0;
        
        order = 6;mode_polyfit = 0;
        [fm] = fm_polyfitting(fm,Mask4fitting,voxel_size, order,mode_polyfit);
        fm2phase = 2*pi*delta_TE.*fm;
        %
        iFreq = iFreq.*exp(-1i*fm2phase);
        %
        unwrap_mode = 3;
        [algoParams] = FatCats_SetAlgoParams4IEV_PUROR(iFreq, unwrap_mode);
        algoParams.complex4mask = iMag;
        [algoParams] = FatCats_unwrapPhaseUsingPUROR(algoParams);
        RDF = algoParams.unwrap_phase;
        %
        [base] = fm_polyfitting(RDF,Mask4fitting,voxel_size, 3,mode_polyfit);
        RDF = RDF - base;
        clear base;
        clear algoParams;
        %
        Mask = iMag>0.01*prctile(iMag(:),95); % for QSM
        %Mask(:,:,(size(RDF,3)-4):(size(RDF,3))) = 0;Mask(:,:,1:3) = 0;
        RDF = RDF.*Mask;
    %
    %B0_dir = [0 0 1];
    lambda = 1000; max_iter = 2;% important parameter, may need modified for different data sets
    [x, cost_reg_history, cost_data_history] = MEDI_L1_JL(iMag,RDF,N_std,Mask,voxel_size,B0_dir,lambda,max_iter);
    chi = x./(2*pi*delta_TE*CF)*1e6;
    RDF = RDF./(2*pi*delta_TE);
    %
    if sum(B0_dir_check(:)) ~= 0
        for ii = 1:3
        index_tmp = find(ax_shift == ii);
        ax_shift_new(ii) =  index_tmp;
        end
        ax_shift = ax_shift_new; clear ax_shift_new;
        %
        iFreq = permute(iFreq,ax_shift);
        RDF = permute(RDF,ax_shift);
        Mask = permute(Mask,ax_shift);
        iMag = permute(iMag,ax_shift);
        N_std = permute(N_std,ax_shift);
        chi = permute(chi,[ax_shift 4]); 
    end
    %
