function [base] = fm_polyfitting(PhaseError,brain_mask,voxel_size, order, mode)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
%
    %
    brain_mask(isnan(brain_mask)) = 0;
    map = PhaseError;
    matrix_size = size(map);
    if length(matrix_size) == 2
    matrix_size(3) = 1;
    end
    [x, y, z] = size(map);
    %
    flag_mode = 3;
    %
    if flag_mode == 2
    base = zeros(matrix_size(1:3)); 
    out_P = zeros(matrix_size(3),3);
    mask_tmp = ones(matrix_size(1:2));
    for index_slice = 1:matrix_size(3)
        map_2D(:,:) = map(:,:,index_slice);
        mask_2D(:,:) = brain_mask(:,:,index_slice);
        if sum(mask_2D(:)) < 100
        mask_2D(:,:) = mask_tmp;%
        else
            mask_tmp = mask_2D;
        end
        %mask_2D = mask_2D.*square_ROI;
        maproi = logical(mask_2D);

    %Get the FOV dimensions from the matrix dimensions:
    X = (-floor(x/2):(x - floor(x/2) - 1)).*voxel_size(1);
    X = X';
    Y = (-floor(y/2):(y - floor(y/2) - 1)).*voxel_size(2);
    [xx yy] = ndgrid(X,Y);
    %size(xx)
    %size(yy)
    %Z = (-floor(z/2):(z - floor(z/2) - 1)).*1;
    
    % Compute the k^2 values:
    %X = reshape(X, [x 1]);   
    %Y = reshape(Y, [1 y]);
    %Z = reshape(Z, [1 1 z]);

    %Create the basis functions:
    %X = X(:, ones(1,y));
    %Y = Y(ones(1,x), :);
    %Z = Z(ones(1,x), ones(1,y), :);

    %Note that maproi is a logical-type variable and, thus, roi is logical-type.
    roi = maproi(:);

    %Decimate:
    %A = [X(roi) Y(roi) Z(roi)];
    A = [xx(roi), yy(roi)];
    %size(A)
    %size(map_2D)
    %stop
    clear X
    clear Y
    %clear Z

    P = polyfitn(A, map_2D(roi), order);
    out_P(index_slice, 1:length(P.Coefficients)) = P.Coefficients;
    end
    save out_P_2D.mat out_P;
    %P.Coefficients
    clear A;
    A = [xx(:), yy(:)];
    P.Coefficients(1) = median(out_P(:,1));
    P.Coefficients(2) = median(out_P(:,2));
    for index_slice = 1:matrix_size(3)
        P.Coefficients(3) = out_P(index_slice,3);
        base_slice = polyvaln(P,A);
        base(:,:,index_slice) = reshape(base_slice,[matrix_size(1) matrix_size(2)]); 
    %LFSpostFilt = map_2D  - base*1.0;
    %PhaseError_residue = LFSpostFilt;
        debug = 0;
        if debug == 1
        figure(1);
        %subplot(2,2,1);imagesc(map_2D);colormap(gray);%caxis([-12 12])
        %subplot(2,2,2);imagesc(mask_2D);colormap(gray);
        %subplot(2,2,3);imagesc(LFSpostFilt);colormap(gray);%caxis([-12 12])
        %subplot(2,2,4);
        imagesc(base(:,:,index_slice));colormap(gray);%caxis([-25 25])
        end
        %index_slice
        clear base_slice
        %pause
    end       
        
    elseif flag_mode == 3
    maproi = logical(brain_mask);

    %Get the FOV dimensions from the matrix dimensions:
    X = (-floor(x/2):(x - floor(x/2) - 1)).*voxel_size(1);
    Y = (-floor(y/2):(y - floor(y/2) - 1)).*voxel_size(2);
    Z = (-floor(z/2):(z - floor(z/2) - 1)).*voxel_size(3);
    
    % Compute the k^2 values:
    X = reshape(X, [x 1]);   
    Y = reshape(Y, [1 y]);
    Z = reshape(Z, [1 1 z]);

    %Create the basis functions:
    X = X(:, ones(1,y), ones(1,z));
    Y = Y(ones(1,x), :, ones(1,z));
    Z = Z(ones(1,x), ones(1,y), :);

    %Note that maproi is a logical-type variable and, thus, roi is logical-type.
    roi = maproi;
    
    %Decimate:
    A = [X(roi) Y(roi) Z(roi)];

    %clear X
    %clear Y
    %clear Z

    P = polyfitn(A, map(roi), order);

    %P.Coefficients
    if mode == 1
    P.Coefficients(length(P.Coefficients)) = 0;
    end
    %sp = polyn2sympoly(P);
    base = map;
    %
    clear roi;
    mask_all = ones(matrix_size);
    roi_all = logical(mask_all);
    clear A;
    A = [X(roi_all) Y(roi_all) Z(roi_all)];
    
    clear X
    clear Y
    clear Z
    
    %
    base(roi_all) = polyvaln(P,A);
    %size(base)
    %size(map)
    LFSpostFilt = map  - base*1.0;
    %PhaseError_residue = LFSpostFilt;
    debug = 0;
    if debug == 1
        for index_slice = 1:matrix_size(3)
        figure(1);
        subplot(2,2,1);imagesc(map(:,:,index_slice));colormap(gray);%caxis([-12 12])
        subplot(2,2,2);imagesc(brain_mask(:,:,index_slice));colormap(gray);
        subplot(2,2,3);imagesc(LFSpostFilt(:,:,index_slice));colormap(gray);%caxis([-12 12])
        subplot(2,2,4);imagesc(base(:,:,index_slice));colormap(gray);%caxis([-25 25])
        index_slice
        pause
        end
    end
    end
    %
    %save([PhaseErrorfile,'_polyfitn.mat'],'PhaseError');
    %
end

