function [algoParams] = FatCats_SetAlgoParams4IEV_PUROR(complex_B0,unwrap_mode)
%--------------
%set up default algoParams
% for phase unwrapping
algoParams.th4unwrap = 0.0; 
algoParams.th4supp = 0.5;
algoParams.th4STAS = 8.0;
algoParams.complex_B0 = complex_B0;
algoParams.matrix_size = size(complex_B0);
algoParams.unwrap_mode = unwrap_mode;
%if algoParams.matrix_size(3) < 5
%algoParams.unwrap_mode = 2; % 2 for 2D PUROR; 3 for 3D PUROR
%else
%algoParams.unwrap_mode = 3; % 2 for 2D PUROR; 3 for 3D PUROR    
%end
% Note that the above parameters may need be optimized for some specific cases
% for example, ch-by-ch unwrapping related to intensity inhomogeneity
%---------------------------------------------
%algoParams.FILTsize = 11;

    algoParams.complex_oriB0 = complex_B0;
    algoParams.phase_oriB0 = angle(complex_B0);
    algoParams.FILTsize = 1;
    if algoParams.FILTsize > 1
        H = fspecial('average',[algoParams.FILTsize algoParams.FILTsize]);
        for index_slice = 1:algoParams.matrix_size(3)
        complex_B0slice(:,:) = complex_B0(:,:,index_slice);
        real_B0slice = imfilter(real(complex_B0slice),H);
        imag_B0slice = imfilter(imag(complex_B0slice),H);
        complex_B0(:,:,index_slice) = real_B0slice + 1i*imag_B0slice;
        end
        clear complex_B0slice
        algoParams.complex_B0 = complex_B0;
    end
    