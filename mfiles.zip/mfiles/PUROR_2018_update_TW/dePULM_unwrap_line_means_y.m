% DEPULM_UNWRAP_LINE_MEANS_Y: Unwrap image at row level using row means
%
%   USAGE: [phase_out] = dePULM_unwrap_line_means_y(phase_input,mask, cell_connect)
%
%   INPUTS:
%       phase_input     - (m x n) array / phase image
%       cell_connect    - well connected points
%
%       N.B. 'cell' inputs are cell arrays of lists
%
%   OUTPUTS:
%       phase_out       - (m x n) array with row means unwrapped
%
%   SEE ALSO : DEPULM_2D_MEAN, DEPULM_UNWRAP_LINE_MEANS
function [phase_out] = dePULM_unwrap_line_means_y(phase_input,mask, cell_connect)
    
    phase_out = dePULM_unwrap_line_means(phase_input', mask', cell_connect);
    phase_out = phase_out';
    
end