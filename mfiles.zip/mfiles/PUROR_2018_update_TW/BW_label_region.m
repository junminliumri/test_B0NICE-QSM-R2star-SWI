%
function [BW_label size_area] = BW_label_region(unwrapped_phase,mask_2D_h, debug_PUROR)
%
pi_2 = 2*pi;
%
B0_map = unwrapped_phase;
matrix_size = size(B0_map);
if length(matrix_size) == 2
matrix_size(3) = 1;
end
%-------------------------
th4label = pi;
%-------------------------
diff_step = 1;       
for index_slice = 1:matrix_size(3)
    %---------------------------
    mask_x = zeros(matrix_size(1:2));
    mask_y = zeros(matrix_size(1:2));
    %---------------------------
    B0_unit(:,:) = B0_map(:,:,index_slice);
    diff_x = diff(B0_unit,diff_step,1);
    diff_x(abs(diff_x) >= th4label) = 1;
    diff_x(abs(diff_x) ~= 1) = 0;
    %----------------------------
    %diff_x = imerode(diff_x,se);
    mask_x((diff_step):(matrix_size(1)-1),:) = diff_x;
    %mask_x(1,:) = 0;
    mask_x((matrix_size(1)-1),:) = 0;
    %----------------------------    
    diff_y = diff(B0_unit,diff_step,2);
    diff_y(abs(diff_y) >= th4label) = 1;
    diff_y(abs(diff_y) ~= 1) = 0;
    %----------------------------
    %diff_y = imerode(diff_y,se);
    mask_y(:,(diff_step+0):(matrix_size(2)-1)) = diff_y;
    %mask_y(:,1) = 0;
    mask_y(:,(matrix_size(2)-1)) = 0;
    %----------------------------
    mask_xy = mask_x + mask_y;
    mask_xy(mask_xy > 0) = 1;
    mask_xy(mask_2D_h(:,:,index_slice) == 0) = 1;
    %
    mask_tmp = zeros(matrix_size(1:2));
    mask_tmp(mask_xy == 0) = 1;
    %
    %----------------------------------------
    % set the boundary pixels belong to the edge
    %mask_tmp(1,:) = 1;
    %mask_tmp(matrix_size(1),:) = 1;
    %mask_tmp(:,1) = 1;
    %mask_tmp(:,matrix_size(2)) = 1;    
    %----------------------------------------
    %
    [L, num] = bwlabel(mask_tmp, 4);
    %num
    s  = regionprops(L, 'area');
    [y_area I_area] = sort([s.Area],'descend');
    %
    y_area(y_area < 49) = []; % the smallest can be used = 4
    size_area = y_area;
%    pause
    %
    se = strel('disk',1);
    BW_L_tmp = zeros(matrix_size(1:2));
    for index_L = 1:length(y_area)
        BW_tmp = zeros(matrix_size(1:2));
        BW_tmp(L == I_area(index_L)) = 1;
        %
        BW_tmp = imdilate(BW_tmp,se);
        %--------
        BW_tmp(mask_xy == 0) = 1;
        [L_tt, num_tt] = bwlabel(BW_tmp, 4);
        s_tt  = regionprops(L_tt, 'area');
        [y_area_tt I_area_tt] = sort([s_tt.Area],'descend');
        BW_tmp = zeros(matrix_size(1:2));
        BW_tmp(L_tt == I_area_tt(1)) = 1;
        mask_xy(BW_tmp == 1) = 1;
        if index_L ~= 1
        BW_tmp = imfill(BW_tmp,'holes');
        end
        %imagesc(BW_tmp);axis square;axis off;
        %index_L
        %pause
        %-------
        BW_L_tmp(BW_tmp == 1) = index_L;
    end
    %
    BW_label(:,:,index_slice) = BW_L_tmp;
    %
    if debug_PUROR == 1
    figure(8)
    subplot(1,3,1);imagesc(BW_label(:,:,index_slice),[0 5]);colormap gray;axis square;axis off;
    subplot(1,3,2);imagesc(mask_2D_h(:,:,index_slice),[0 5]);colormap gray;axis square;axis off;
    subplot(1,3,3);imagesc(unwrapped_phase(:,:,index_slice));colormap gray;axis square;axis off;     
    index_slice
    pause
    end
    %
end
%

%
