function [phase_out] = dePULM_connect_line_segments_y(phase_input,mask)
    
    phase_out = dePULM_connect_line_segments(phase_input', mask');
    
    phase_out = phase_out';

end