
function [unwrap_phase] = PUROR2D(data_RawB0,mask4unwrap,mask4supp,mask4STAS)
%
%----------------------------------------------------------------------
%   2D unwrapping with PUROR 
%-----------------------------------------------------------------------
pi_2 = 2*pi;
%----------------------------------------------------------------------
%   Start phase unwrapping
%----------------------------------------------------------------------
slice_start = 1;
slice_end = size(data_RawB0,3);
%
unwrap_phase = angle(data_RawB0(:,:,:));
for index_slice = slice_start:slice_end   
%
%index_slice
%----------------------------------------------------------------------
% generating the original magnitude and phase images
%----------------------------------------------------------------------e   
   data_slice(:,:) = data_RawB0(:,:,index_slice); 
%----------------------------------------------------------------------
MASK_2D_unwrap(:,:) = mask4unwrap(:,:,index_slice);
MASK_2D_supp(:,:) = mask4supp(:,:,index_slice);
MASK_stas(:,:) = mask4STAS(:,:,index_slice);
%-----------------------------------------------------------------
[unwrapped_phase_x unwrapped_phase_y] = dePULM_2D_doit_updated(angle(data_slice),MASK_2D_unwrap,MASK_2D_supp);
%--------------------------------------------------------------------------
phase_tmp_mean = unwrapped_phase_x(:);
phase_tmp_mean(MASK_stas(:) == 0) = [];
phase_tmp_mean(isnan(phase_tmp_mean)) = [];
tmp_mean = mean(phase_tmp_mean);
unwrapped_phase_x(MASK_2D_unwrap == 1) = unwrapped_phase_x(MASK_2D_unwrap == 1) - pi_2*round(tmp_mean/pi_2);
%
tmp_mean = tmp_mean - pi_2*round(tmp_mean/pi_2);
mean_2D_x(index_slice) = tmp_mean;
%
phase_tmp_mean = unwrapped_phase_y(:);
phase_tmp_mean(MASK_stas == 0) = [];
phase_tmp_mean(isnan(phase_tmp_mean)) = [];
tmp_mean = mean(phase_tmp_mean);
unwrapped_phase_y(MASK_2D_unwrap == 1) = unwrapped_phase_y(MASK_2D_unwrap == 1) - pi_2*round(tmp_mean/pi_2);
tmp_mean = tmp_mean - pi_2*round(tmp_mean/pi_2);
mean_2D_y(index_slice) = tmp_mean;
%--------------------------------------------------------------------------

%--------------------------------------------------------------------------
%   2D phase_unwrapping was done
%---------------------------------------
%    unwrapping_time = cputime - t_seg
    unwrap_phase(:,:,index_slice) = unwrapped_phase_x;  
%    figure(7)
%    imagesc(unwrapped_phase_x,[-pi_2 pi_2]);colormap gray;
%    stop
%    pause
%    figure(8)
%    imagesc(unwrapped_phase_y,[-pi_2 pi_2]);colormap gray;
%    figure(9)
%    imagesc((unwrapped_phase_y - unwrapped_phase_x), [-pi pi]);colormap gray;
%    pause
%    figure(9)
%    mesh(unwrapped_phase_x);
end % for index_slice 
%-------------------------------------
    %
end
%---------------------------------------------------------------------
