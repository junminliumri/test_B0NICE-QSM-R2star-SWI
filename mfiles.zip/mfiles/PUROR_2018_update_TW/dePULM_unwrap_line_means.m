% DEPULM_UNWRAP_LINE_MEANS: Unwrap image at row level using row means
%
%   USAGE: [phase_out] = dePULM_unwrap_line_means(phase_input,mask, cell_connect)
%
%   INPUTS:
%       phase_input     - (m x n) array / phase image
%       cell_connect    - well connected points
%
%       N.B. 'cell' inputs are cell arrays of lists
%
%   OUTPUTS:
%       phase_out       - (m x n) array with row means unwrapped
%
%   SEE ALSO : DEPULM_2D_MEAN, DEPULM_UNWRAP_LINE_MEANS_Y
function [phase_out] = dePULM_unwrap_line_means(phase_input, mask, cell_connect)
    
    pi_2 = pi*2.0;
    [num_rows, num_cols] = size(phase_input);
    
    phase_out    = zeros(num_rows,num_cols);
    mean_connect = zeros(1,num_rows);
    
    %Start from second row and do first row last
    for row = [2:num_rows 1]
        
        index_signal  = find(mask(row,:));
        index_connect = cell_connect{row};
        use_connect   = length(index_connect) > 3;
        
        if isempty(index_signal)
            
            %If there is no signal
            %Use phase mean from adjacent row
            if row == 1
                mean_connect(1)   = mean_connect(2);
            else
                mean_connect(row) = mean_connect(row - 1);
            end
            
        else
            %If there is signal
            %Get array of points in row
            phase_signal = zeros(1,num_cols);
            phase_signal(index_signal) = phase_input(row,index_signal);
            
            if  use_connect
                %If there are enough 'well connected' points use them
                phase_x = phase_signal(index_connect);
            else
                %Otherwise, use all points in mask
                phase_x = phase_signal(index_signal);
            end
            
            %Get mean phase value
            row_mean = sum(phase_x, 'omitnan')/length(phase_x);        %'****N.B*****' omitnan' ignores NaNs. mean_liu replaced them with 0s.
            %Wrap row mean into [-pi, pi)
            phase_out(row,index_signal) = phase_signal(index_signal) - round(row_mean/pi_2)*pi_2;
            
            if  use_connect
                %If there are enough 'well connected' points use them
                phase_x = phase_out(row, index_connect);
            else
                %Otherwise, use all points in mask
                phase_x = phase_out(row, index_signal);
            end
            
            %Get mean phase value
            row_mean = sum(phase_x, 'omitnan')/length(phase_x);
            
            mean_connect(row) = row_mean;
            
        end
        
    end
    
    %--------------------------------------------------------------------
    %   Start line shift by unwrapping the means
    %--------------------------------------------------------------------
    %   unwrap the mean values before shifting the phase data, so
    %   the center line is in [-pi, pi)
    center_line = round(num_rows/2);
    mean_unwrap = unwrap(mean_connect);
    mean_unwrap = mean_unwrap - round(mean_unwrap(center_line)/pi_2)*pi_2;
    unwrap_diff = mean_unwrap - mean_connect;
    
    %   shift the phase data
    for row = 1:num_rows
        
        row_diff = unwrap_diff(row);
        
        if abs(row_diff) > pi
            phase_out(row,:) = phase_out(row,:)  + pi_2*round(row_diff/(pi_2)).*mask(row,:);
        end
        
    end
end