% DEPULM_2D_QUALITY_Y: Identifies best vertical strip in unwrapped phase.
%                      Quality based on orthogonal phase gradient
%
%   USAGE: [quality, stripStart, stripEnd] = dePULM_2D_quality_y(phase, mask)
%
%   INPUTS:
%       phase           - (m x n) array / phase image
%       mask            - (m x n) binary array of points to use
%
%   OUTPUTS:
%       quality         - (1 x m) array of row quality
%       stripStart      - first column in best strip
%       stripEnd        - last  column in best strip
%
%   N.B. 'best strip' is biased to higher/later columns
%   SEE ALSO : DEPULM_2D_QUALITY, DEPULM_2D_XY_CEN_Y,
function [quality_br, xy_start, xy_end] = dePULM_2D_quality_y(phase,mask)
    [quality_br, xy_start, xy_end] = dePULM_2D_quality(phase',mask');
end
