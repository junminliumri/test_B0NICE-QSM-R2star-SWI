% DEPULM_2D_INI_XY_CONNECT: Identify connected parts of the mask for each
%                           row or   column
%   USAGE: [cell_connect_x, cell_connect_y] = dePULM_2D_ini_xy_connect(mask)
%
%   INPUTS:
%       mask - (m x n) binary array
%
%   OUTPUTS:
%       cell_connect_x   - m lists of well connected points in each row
%       cell_connect_y   - n lists of well connected points in each column
%   NOTES:
%       cell_connect cannot have points on the outside, this is to match
%       previous implementation. To include, switch to
%       "find(connected_xy(row,:))" etc
%
%   SEE ALSO : DEPULM_2D_INI_XYSS, DEPULM_2D_INI, DEPULM_2D_INI_Y
function [cell_connect_x, cell_connect_y] = dePULM_2D_ini_xy_connect(mask)
    
    [nRows, nColumns] = size(mask);
    
    cell_connect_x = cell(1,nRows);
    cell_connect_y = cell(1,nColumns);
    
    connected_x=imerode(logical(mask), [true true true]);       %Find points without points left  and right
    connected_y=imerode(logical(mask), [true;true;true]);       %Find points without points above and below
    
    connected_xy=connected_y & connected_x;                     %Get map of points in both categories
    
    for row = 1:nRows
        
        connected=find(connected_xy(row,2:end-1))+1;            %Look in each row for 4 neighbor points
        
        if length(connected) <= nColumns/4                      %If not enough, use 2 neghbour points (up/down)
            connected=find(connected_y(row,2:end-1))+1;
        end
        
        cell_connect_x(1,row) = {connected};                    %Record these points
        
    end
    
    for col = 1:nColumns
        
        connected=find(connected_xy(2:end-1, col))+1;           %Look in each column for 4 neighbor points
        
        if length(connected) <= nRows/4                         %If not enough, use 2 neghbour points (left/right)
            connected=find(connected_x(2:end-1, col))+1;
        end
        
        cell_connect_y(1,col) = {connected};                    %Record these points
        
    end
    
end
