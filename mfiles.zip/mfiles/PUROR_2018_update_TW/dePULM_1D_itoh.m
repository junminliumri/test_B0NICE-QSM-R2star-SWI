% DEPULM_1D_ITOH: unwraps rows and columns of phase image in alternating directions
%
%   USAGE: [phase_itoh_x, phase_itoh_y] = dePULM_1D_itoh(phase_original)
%
%   INPUTS:
%       phase_original - (m x n) array / phase image to unwrap
%
%   OUTPUTS:
%       phase_itoh_x - (m x n) array with unwrapped rows
%       phase_itoh_y - (m x n) array with unwrapped columns
%
%   SEE ALSO : DEPULM_2D_ITOH
function [phase_itoh_x, phase_itoh_y] = dePULM_1D_itoh(phase_original)
    
    [nRows, nCols] = size(phase_original);
    
    phase_itoh_x(2:2:nRows,:)          = unwrap(phase_original(2:2:nRows,:), [], 2);            %unwrap even rows left to right
    phase_itoh_x(1:2:nRows,nCols:-1:1) = unwrap(phase_original(1:2:nRows,nCols:-1:1), [], 2);   %unwrap odd  rows right to left
    
    phase_itoh_y(:,2:2:nCols)          = unwrap(phase_original(:,2:2:nCols), [], 1);            %unwrap even columns top to bottom
    phase_itoh_y(nRows:-1:1,1:2:nCols) = unwrap(phase_original(nRows:-1:1,1:2:nCols), [], 1);   %unwrap odd  columns bottom to top
end
