function [out_x, out_y] = dePULM_3D_check_updated(unwrapped_x_2D, unwrapped_y_2D, original_phase,mask)
    
    [nRows, nColumns, nSlices] = size(unwrapped_x_2D);
    out_x = unwrapped_x_2D;
    out_y = unwrapped_y_2D;
    
    for show_x_z = 1:nRows
        
        D3_xz  = squeeze(unwrapped_y_2D(show_x_z,:,nSlices:-1:1))';
        phase_xz = squeeze(original_phase(show_x_z,:,nSlices:-1:1))';
        
        %[quality_br] = dePULM_2D_quality(D3_xz,D3_xz);
        
        if true% sum(quality_br > 0.95) > 3
            [itoh_xz, mask_xz] = dePULM_2D_itoh(D3_xz,phase_xz);
            [~, phase_xz]  = dePULM_3D_doit_updated(D3_xz,itoh_xz,mask_xz,mask_xz);
            unwrapped_y_2D(show_x_z,:,nSlices:-1:1) = phase_xz'; %This corresponds to ori_xz, which would be the original phase without the if, I don't think it should be outside loop
        end
    end
    
    for show_y_z = 1:nColumns
        D3_yz    = squeeze(unwrapped_x_2D(:,show_y_z,nSlices:-1:1))';
        phase_yz = squeeze(original_phase(:,show_y_z,nSlices:-1:1))';
        
        %[quality_br] = dePULM_2D_quality(D3_yz,D3_yz);
        
        if true %sum(quality_br > 0.95) > 3
            [itoh_yz, mask_yz] = dePULM_2D_itoh(D3_yz,phase_yz);
            [~, phase_yz]   = dePULM_3D_doit_updated(D3_yz,itoh_yz,mask_yz,mask_yz);
            unwrapped_x_2D(:,show_y_z,nSlices:-1:1) = phase_yz'; % vide supra
        end
    end
    
    for index_slice = 1:nSlices
        unwrapped_phase_x = unwrapped_x_2D(:,:, index_slice);
        unwrapped_phase_y = unwrapped_y_2D(:,:, index_slice);
        %
        %         %[quality_br] = dePULM_2D_quality(unwrapped_phase_x,unwrapped_phase_y);
        if true%sum(quality_br > 0.95) > 3
            mask_xy = mask(:,:, index_slice);
            seg_phi = pi;
            for test_loop = 1:6
                [unwrapped_phase_y] = dePULM_cross_refer_y_against_x(unwrapped_phase_x, unwrapped_phase_y,seg_phi,mask_xy);
                [unwrapped_phase_x] = dePULM_cross_refer_x_against_y(unwrapped_phase_y, unwrapped_phase_x,seg_phi,mask_xy);
                seg_phi = seg_phi/2;
            end
            
            [unwrapped_phase_x]     = dePULM_2D_diff(unwrapped_phase_x);
            [unwrapped_phase_y]     = dePULM_2D_diff_y(unwrapped_phase_y);
        end
        out_x(:,:,index_slice) = unwrapped_phase_x;
        out_y(:,:,index_slice) = unwrapped_phase_y;
    end
end

