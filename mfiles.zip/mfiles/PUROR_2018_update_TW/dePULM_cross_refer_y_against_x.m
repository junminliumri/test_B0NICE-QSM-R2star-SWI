% DEPULM_CROSS_REFER_Y_AGAINST_X: Cross refers an unwrapped phase image
%                                 with another phase image. Operates on
%                                 line segments with gradient under seg_phi
%
%   USAGE: [phase_out] = dePULM_cross_refer_y_against_x(reference_phase,phase_input,seg_phi,mask)
%
%   INPUTS:
%       reference_phase - (m x n) array / phase image used as reference
%       phase_input     - (m x n) array / phase image to shift
%       seg_phi         - maximum gradient of a line segment
%       mask            - (m x n) binary array of points to use
%
%   OUTPUTS:
%       phase_out - (m x n) array shifted to match high quality strip
%
%   SEE ALSO : DEPULM_CROSS_REFER_X_AGAINST_Y DEPULM_2D_QUALITY
function [phase_out] = dePULM_cross_refer_y_against_x(reference_phase, phase_input,seg_phi,mask)
    
    [num_rows, num_cols] = size(phase_input);
    pi_2 = pi*2.0;
    width_threshold = 3;
    
    phase_out = phase_input;
    
    %Calculate difference between two images
    phase_diff = reference_phase-phase_input;
    
    %Remove low signal points
    phase_diff = phase_diff.*mask;
    
    %Get the running sum of columns (faster than summing later)
    phase_sum      = [zeros(1, num_cols); cumsum(phase_diff)];
    
    %Get running sum of mask (faster than counting later)
    mask_sum       = [zeros(1, num_cols); cumsum(mask)];
    
    %Make a mask of where gradient is less than threshold
    gradient_mask  = [abs(diff(phase_input)) <= seg_phi; zeros(1, num_cols) ] ;
    
    %Combine the two masks
    good_points = gradient_mask & mask;
    
    %Mark points where this new mask either starts or ends segments
    dgp=diff([zeros(1,num_cols);good_points]);
    
    ext_mask = [mask;zeros(1, num_cols)];
    
    for col = 1:num_cols
        
        phase_shift = zeros(num_rows,1);
        num_seg = 0;
        
        %Get start points of line segments
        start_list = find(dgp(:,col)==1);
        
        %Get end points of line segments
        end_list   = find(dgp(:,col)==-1)-1;
        
        for ii = 1:length(start_list)
            this_start = start_list(ii);
            this_end   = end_list(ii);
            
            %If segment is a single point go to next segment
            if(this_start==this_end)
                continue
            end
            
            if(ext_mask(this_end+1, col))
                this_end=this_end+1;
            end
            
            %Check if strip big enough, record mean difference for shift
            if this_end - this_start >= width_threshold
                num_seg = num_seg + 1;
                
                seg_phase_diff = (phase_sum(this_end+1,col)-phase_sum(this_start,col))/(mask_sum(this_end+1,col)-mask_sum(this_start,col));
                
                if abs(seg_phase_diff) > pi
                    phase_shift(this_start:this_end) = pi_2*round(seg_phase_diff/pi_2);
                end
                
                %If this isn't the first segment, record shift for between segements
                if num_seg > 1
                    
                    inter_start  = prev_end + 1;
                    inter_end    = this_start -1;
                    if inter_end >= inter_start
                        mean_start = inter_start - 2;
                        mean_end   = inter_end + 2;
                        seg_phase_diff = (phase_sum(mean_end+1,col)-phase_sum(mean_start, col))/(mask_sum(mean_end+1,col)-mask_sum(mean_start,col));
                        
                        if abs(seg_phase_diff) > pi
                            phase_shift(inter_start:inter_end) = pi_2*round(seg_phase_diff/pi_2);
                        end
                    end
                    
                end
                
                prev_end = this_end;
                
            end
        end
        
        phase_out(:,col) = phase_input(:,col)+phase_shift.*mask(:,col);
    end
end
