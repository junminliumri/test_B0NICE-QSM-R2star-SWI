function [ unwrapped_phase_x, unwrapped_phase_y ] = StackSlice_Igor(unwrapped_phase_x, unwrapped_phase_y, mask4stack)
%Unwraps volume in the slice direction

unwrapped_phase_x=StackSlice_int(unwrapped_phase_x,mask4stack);
if nargout>1
    unwrapped_phase_y=StackSlice_int(unwrapped_phase_y,mask4stack);
end

end


function ph = StackSlice_int(ph,mask)
pi_t = pi*2;
%find mean phase of each slice
masked_phase=bsxfun(@times,ph,double(mask));
mean_2D=squeeze(sum(sum(masked_phase,1),2))./squeeze(sum(sum(mask,1),2));
mean_2D(isnan(mean_2D))=0;

%unwrap 1D mean phase vector
slice_centre = round(size(ph,3)/2);
unwrap_mean = unwrap(mean_2D);
unwrap_mean = unwrap_mean - 2*pi*round(unwrap_mean(slice_centre)/2/pi);

%apply the difference between wrapped an unwrapped mean phase to each slice
diff_mean = mean_2D - unwrap_mean;

for index_slice = 1:size(ph,3)
    ph(:,:,index_slice) = ph(:,:,index_slice) - pi_t*round(diff_mean(index_slice)/pi_t);
end

end