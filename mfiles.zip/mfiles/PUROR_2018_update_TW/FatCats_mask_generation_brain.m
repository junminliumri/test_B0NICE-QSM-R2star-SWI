% FATCATS_MASK_GENERATION_BRAIN: Create mask for unwrapping based on
%                                thresholding small neighbourhood
%
%   USAGE: [algoParams] = FatCats_mask_generation(algoParams)
%
%   INPUTS:
%       algoParams      - structure with image, matrix size and noise slices
%
%   OUTPUTS:
%       algoParams      - input structure now containing masks
%
%   SEE ALSO : DEPULM_2D_MASK
function [algoParams] = FatCats_mask_generation_brain(algoParams)
    
    complex_image = algoParams.complex_image;
    matrix_size   = algoParams.matrix_size;
    noise_slice   = algoParams.noise_slice;
    
    H = fspecial('gaussian',3);
    
    mask_0_unwrap = zeros(matrix_size(1),matrix_size(2),matrix_size(3));
    mask_h_unwrap = zeros(matrix_size(1),matrix_size(2),matrix_size(3));
    mask4STAS     = zeros(matrix_size(1),matrix_size(2),matrix_size(3));
    
    mag_original  = abs(complex_image);
    
    filtered_complex = imfilter(complex_image,H);
    filtered_mag     = abs(filtered_complex);
    
    for index_slice = 1:matrix_size(3)
        background_noise = noise_slice(index_slice);
        mask_0_unwrap(:,:,index_slice) = filtered_mag(:,:,index_slice) >= background_noise*0.0;
        mask_h_unwrap(:,:,index_slice) = filtered_mag(:,:,index_slice) >= background_noise*1.0;
        mask4STAS(:,:,index_slice)     = mag_original(:,:,index_slice) >= background_noise*4.0;
    end
    
    algoParams.mask_0_unwrap = mask_0_unwrap;
    algoParams.mask_h_unwrap = mask_h_unwrap;
    algoParams.mask4STAS     = mask4STAS;
    
end