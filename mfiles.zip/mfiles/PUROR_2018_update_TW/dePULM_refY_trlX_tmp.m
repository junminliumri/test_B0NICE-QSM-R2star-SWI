% this program is for volunteer results acquired using 3D SPGR in GE 3T
% scanner
%
%
function [phase] = dePULM_refY_trlX_tmp(reference_phase, phase, mask, start_dw, start_up)
    
    pi_2 = pi*2.0;
    [num_rows, ~] = size(phase);
    
    %Operate on rows outside protect region
    for row = [1:start_dw start_up:num_rows]
        
        index_phase = find(phase(row,:));
        index_mask  = find(mask(row,:));
        
        if length(index_mask)/length(index_phase) >= 0.3 && length(index_mask) > 6
            index_diff = index_mask;
        else
            index_diff = index_phase;
        end
        
        reference_row = reference_phase(row, index_diff);
        input_row     = phase(row, index_diff);
        
        phase_diff = mean(reference_row-input_row, 'omitnan');
        
        if abs(phase_diff) > pi
            phase(row,index_phase) = phase(row,index_phase) + pi_2*round(phase_diff/pi_2);
        end
        
    end
end

