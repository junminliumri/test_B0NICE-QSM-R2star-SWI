% DEPULM_2D_MASK: Create mask for unwrapping based on thresholding small
%                 neighbourhood
%
%   USAGE: [mask, masked_phase] = dePULM_2D_mask(mag_original, threshold, phase_original)
%
%   INPUTS:
%       mag_original   - (m x n) magnitude array used to determine
%                        inclusion in mask
%       threshold      - minimum magnitude value for mask
%       phase_original - (m x n) phase array to mask
%
%   OUTPUTS:
%       mask           - (m x n) binary array
%       masked_phase   - (m x n) phase array including only points in mask
%
%   SEE ALSO : FATCATS_MASK_GENERATION_BRAIN
function [mask, masked_phase] = dePULM_2D_mask(mag_original, threshold, phase_original)
    
    mask_th = mag_original >= threshold;
    
    yn_mask = movsum(mask_th,3,  'Endpoints', 0)   >=2;
    xn_mask = movsum(mask_th,3,2,'Endpoints', 0)   >=2;
    
    %Not quite an erode, because xy_mask can include a point not in mask_th
    %if all the neighbours are in mask_th.
    xy_mask = xn_mask & yn_mask;
    
    %The rest is dealing with edges to match original.
    
    mask_x = xy_mask;
    mask_y = xy_mask;
    
    mask_x(1,:)   = mask_th(1,:)   & xn_mask(1,:);
    mask_x(end,:) = mask_th(end,:) & xn_mask(end,:);
    
    mask_y(:,1)   = mask_th(:,1)   & yn_mask(:,1);
    mask_y(:,end) = mask_th(:,end) & yn_mask(:,end);
    
    %Cannot combine as (a&b)|c because of corners, (1,2)/(end,end-1) needs to be filled
    %first
    mask_x(:,1)   = mask_x(:,2);
    mask_x(:,end) = mask_x(:,end-1);
    
    mask_y(1,:)   = mask_y(2,:);
    mask_y(end,:) = mask_y(end-1,:);
    
    mask = mask_x | mask_y;
    
    masked_phase = phase_original.*mask;
    
end
