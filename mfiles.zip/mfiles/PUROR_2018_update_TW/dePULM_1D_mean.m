% DEPULM_1D_MEAN: Calculates the mean of the 'connected' pixels in each row and each column
%                 of unwrapped phase image
%
%   USAGE: [mean_connect_y, mean_connect_x] = dePULM_1D_mean(phase,cell_connect_x,cell_connect_y)
%
%   INPUTS:
%       phase          - (m x n) array / unwrapped phase image
%
%   OUTPUTS:
%       mean_connect_y - 1 x m array with mean of unwrapped rows
%       mean_connect_x - 1 x n array with mean of unwrapped columns
%
function [mean_connect_y, mean_connect_x] = dePULM_1D_mean(phase,cell_connect_x,cell_connect_y)
    
    [num_rows, num_cols] = size(phase);
    
    mean_connect_y = zeros(1,num_rows);
    for row = 1:num_rows
        index_conn = cell_connect_x{row};
        mean_connect_y(row) = sum(phase(row,index_conn), 'omitnan')/length(index_conn);
    end
    
    mean_connect_x = zeros(1,num_cols);
    for col = 1:num_cols
        index_conn = cell_connect_y{col};
        mean_connect_x(col) = sum(phase(index_conn,col), 'omitnan')/length(index_conn);
    end
    
end