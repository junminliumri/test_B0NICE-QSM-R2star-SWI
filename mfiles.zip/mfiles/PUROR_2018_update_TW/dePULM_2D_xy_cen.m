% DEPULM_2D_XY_CEN: Shifts values of phase image to match values of high
%                   quality strip identified in reference image
%
%   USAGE: [phase_out] = dePULM_2D_xy_cen(reference_phase,phase_input,xy_start,xy_end,mask)
%
%   INPUTS:
%       reference_phase - (m x n) array / phase image used as reference
%       phase_input     - (m x n) array / phase image to shift
%       xy_start        - start of strip to use as reference
%       xy_end          - end of strip to use as reference
%       mask            - (m x n) binary array of points to use
%
%   OUTPUTS:
%       phase_out - (m x n) array shifted to match high quality strip
%
%   SEE ALSO : DEPULM_2D_XY_CEN_Y DEPULM_2D_QUALITY
function [phase_out] = dePULM_2D_xy_cen(reference_phase,phase_input,xy_start,xy_end,mask)
    
    pi_2 = pi*2.0;
    [~, num_cols] = size(phase_input);
    
    phase_out = phase_input;
    
    for column = 1:num_cols
        
        %This 'finds' 3e-18 etc
        %Is reference supposed to be masked out?
        index_l = find(reference_phase(:,column));
        
        %Identify points in the strip also in the mask
        index_strip = find(mask(xy_start:xy_end,column));
        
        %If no points in strip, check whole column
        %May want to change this to <small number
        if isempty(index_strip)
            index_signal = find(mask(:,column));
        else
            index_signal = index_strip + xy_start - 1;
        end
        
        %Find mean of phase difference between two images in this column
        reference_points = reference_phase(index_signal,column);
        input_points     = phase_input(index_signal,column);
        
        mean_phase_diff = sum(reference_points - input_points, 'omitnan')/length(index_signal); %N.B meanliu counts NaNs as 0
        
        %Add phase difference to this column
        if abs(mean_phase_diff) > pi
            phase_shift = pi_2*round(mean_phase_diff/pi_2);
            phase_out(index_l,column) = phase_input(index_l,column) + phase_shift;
        end
        
    end
    
end