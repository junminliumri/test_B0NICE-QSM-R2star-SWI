% DEPULM_2D_doit_updated: unwraps a single slice using the PUROR method
%   USAGE: [out_x, out_y, mean_y, mean_x] = dePULM_2D_doit_updated(phase_original,mask_2D,mask_2D_h)
%
%   INPUTS:
%       phase_original - (m x n) array / phase image to unwrap
%       mask_2D        - (m x n) mask of pixels to use
%       mask_2D_h      - (m x n) mask of higher quality pixels to use
%
%   OUTPUTS:
%       out_x        - (m x n) unwrapped phase array 
%       out_y        - (m x n) equivalent unwrapped phase_array
%       mean_y       - mean of 'connected' pixels in each row
%       mean_x       - mean of 'connected' pixels in each column
%       
%   SEE ALSO : DEPULM_2D_ITOH
function [out_x, out_y] = dePULM_2D_doit_updated(phase_original,mask_2D,mask_2D_h)
    
    [cell_connect_x_h, cell_connect_y_h] =  dePULM_2D_ini_xy_connect(mask_2D_h);
    
    [phase_itoh_x, phase_itoh_y] = dePULM_1D_itoh(phase_original);
    
    % PROCEDURE 1
    [phase_ls_x] = dePULM_connect_line_segments(phase_itoh_x,mask_2D);
    [ori_phase_x]= dePULM_unwrap_line_means(phase_ls_x, mask_2D, cell_connect_x_h);
    
    [phase_ls_y] = dePULM_connect_line_segments_y(phase_itoh_y,mask_2D);
    [ori_phase_y]= dePULM_unwrap_line_means_y(phase_ls_y, mask_2D, cell_connect_y_h);
    
    %PROCEDURE 2
    [~, xy_start_dw, xy_start_up] = dePULM_2D_quality(ori_phase_x, mask_2D_h);
    
    [unwrapped_phase_y] = dePULM_2D_xy_cen(ori_phase_x,ori_phase_y,xy_start_dw,xy_start_up,mask_2D_h);
    
    [~, xy_start_L, xy_start_R] = dePULM_2D_quality_y(unwrapped_phase_y, mask_2D_h);
    if (xy_start_R - xy_start_L)/(xy_start_up - xy_start_dw) >= 0.5
        [unwrapped_phase_x] = dePULM_2D_xy_cen_y(unwrapped_phase_y,ori_phase_x,xy_start_L,xy_start_R,mask_2D_h);
    else
        [unwrapped_phase_x] = dePULM_refY_trlX_tmp(unwrapped_phase_y, ori_phase_x,mask_2D_h,xy_start_dw,xy_start_up);
    end
    
    %PROCEDURE 3
    seg_phi = pi;
    for test_loop = 1:6       
        [unwrapped_phase_y] = dePULM_cross_refer_y_against_x(unwrapped_phase_x, unwrapped_phase_y,seg_phi,mask_2D);
        
        [unwrapped_phase_x] = dePULM_cross_refer_x_against_y(unwrapped_phase_y, unwrapped_phase_x,seg_phi,mask_2D);
       
        seg_phi = seg_phi/2;
        
    end
    
    [out_x] = dePULM_2D_diff(unwrapped_phase_x);
    
    [out_y] = dePULM_2D_diff_y(unwrapped_phase_y);
    
    H = fspecial('average',3);
    filter_out_x = out_x - imfilter(out_x,H, 'symmetric');

    index_dots = mask_2D_h & abs(filter_out_x)>=pi;
    out_x(index_dots)=out_x(index_dots)-round(filter_out_x(index_dots)/(pi*2))*pi*2;
    %--------------------------------------------------------------------
    %   For the final step
    %--------------------------------------------------------------------
    [mean_y, mean_x] = dePULM_1D_mean(out_x,cell_connect_x_h,cell_connect_y_h);
    %--------------------------------------------------------------------------
    %   phase_unwrapping was done
    %--------------------------------------------------------------------------
    
