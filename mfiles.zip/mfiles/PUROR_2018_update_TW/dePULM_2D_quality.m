% DEPULM_2D_QUALITY: Identifies best horizontal strip in unwrapped phase.
%                    Quality based on orthogonal phase gradient
%
%   USAGE: [quality, stripStart, stripEnd] = dePULM_2D_quality(phase, mask)
%
%   INPUTS:
%       phase           - (m x n) array / phase image
%       mask            - (m x n) binary array of points to use
%
%   OUTPUTS:
%       quality         - (1 x m) array of row quality
%       stripStart      - first row in best strip
%       stripEnd        - last  row in best strip
%
%   N.B. 'best strip' is biased to higher/later rows
%
%   SEE ALSO : DEPULM_2D_QUALITY_Y, DEPULM_2D_XY_CEN,
%   DEPULM_REFY_TRLX_TMP
function [quality, strip_start, strip_end] = dePULM_2D_quality(phase,mask)
    
    [num_rows, ~] = size(phase);
    quality = -ones(1,num_rows);
    
    %Find points in mask with neighbours above and below
    quality_points = imerode(mask, [1;1;1]);
    
    %Loop through interior rows
    for row = 2:num_rows-1
        index_x=find(quality_points(row,:));
        if ~isempty(index_x)
            len_x   = length(index_x);
            diff_up = phase(row,index_x) -  phase(row - 1,index_x);
            diff_dw = phase(row,index_x) -  phase(row + 1,index_x);
            
            %Mark points where gradient is above pi
            q_up   = find(abs(diff_up) > pi);
            len_up = length(q_up);
            
            q_dw   = find(abs(diff_dw) > pi);
            len_dw = length(q_dw);
            
            quality_up   = (len_x - len_up)/len_x;
            quality_dw   = (len_x - len_dw)/len_x;
            quality(row) = quality_up*quality_dw;
        end
    end
    
    %Do top row
    index_x=find(quality_points(1,:));
    if ~isempty(index_x)
        len_x   = length(index_x);
        diff_dw = phase(1,index_x) -  phase(2,index_x);
        q_dw    = find(abs(diff_dw) > pi);
        len_dw  = length(q_dw);
        
        quality(1) = (len_x - len_dw)/len_x;
    end
    
    %Do bottom row
    index_x=find(quality_points(num_rows,:));
    if ~isempty(index_x)
        len_x   = length(index_x);
        diff_up = phase(num_rows,index_x) -  phase(num_rows-1,index_x);
        q_up    = find(abs(diff_up) > pi);
        len_up  = length(q_up);
        
        quality(num_rows) = (len_x - len_up)/len_x;
    end
    
    %Find the protect region (largest hiqh quality strip)
    if nargout > 1
        
        is_high_quality = quality > 0.9;
        
        max_length = 1;
        strip_end  = 1;
        
        strip_length=0;
        
        for row = 1:num_rows
            
            if is_high_quality(row)
                strip_length = strip_length+1;
            else
                
                if strip_length >= max_length
                    max_length   = strip_length;
                    strip_end    = row-1;
                end
                
                strip_length=0;
                
            end
            
        end
        
        %If the last row is high quality, check if it ends the largest strip
        if strip_length >= max_length
            strip_end    = row;
            max_length   = strip_length;
        end
        
        strip_start = strip_end - max_length + 1;
        
    end
    
end
