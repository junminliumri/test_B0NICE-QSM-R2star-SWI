% DEPULM_CONNECT_LINE_SEGMENTS: Identify line segments in mask where gradient is
%                          beneath threshold (pi/2)
%                          Connect those line segments
%
%   USAGE: [phase_out] = dePULM_connect_line_segments(phase_input,mask)
%
%   INPUTS:
%       phase_input     - (m x n) array / phase image
%       mask            - (m x n) binary array of points to use
%
%   OUTPUTS:
%       phase_out
%
%   NOTES:
%       1D unwrapping alternates directions. Would that help here?
%       Reset (count) when segment too short missing in earlier MATLAB code
%
%   SEE ALSO : DEPULM_1D_LS_MERGE
function [phase_out] = dePULM_connect_line_segments(phase_input,mask)
    
    [num_rows, num_cols] = size(phase_input);
    
    phi_good = 0.5*pi;
    pi_2 = pi*2.0;
    width_threshold = 3;
    
    phase_out = phase_input;%zeros(num_rows,num_cols);
    
    %Mark points where gradient is under a threshold
    %Appending 0 allows this to work as an 'in-range' check as well
    good_points = [abs(diff(phase_input,1,2)) <= phi_good zeros(num_rows,1)];
    
    %Combine gradient threshold mask with signal mask
    good_points = good_points & mask;
    
    for row = 1:num_rows
        
        row_phase  = phase_input(row, :);
        row_mask   = mask(row, :);
        row_points = good_points(row,:);
        
        ii = 1;
        num_seg = 0;
        first_start = 1;
        prev_end    = length(row_phase);
        
        if sum(row_mask) > num_cols/4
            
            while ii < length(row_phase)
                
                if row_points(ii)
                    
                    start = ii;
                    
                    %Continue until a point not in both masks is found
                    while(row_points(ii+1))
                        ii = ii+1;
                    end
                    %Checking last pixel is in the signal mask is faster than
                    %checking both masks individually each time
                    if row_mask(ii+1)
                        ii=ii+1;
                    end
                    
                    if ii - start >= width_threshold
                        num_seg = num_seg + 1;
                        
                        if num_seg == 1
                            first_start = start;
                        else
                            %Should this count all or just nonzeros?
                            dist = nnz(row_mask(prev_end:start))-1;
                            
                            if dist <= 6
                                
                                end_mean   = sum(row_phase(prev_end-2:prev_end));
                                
                                next_start_mean = sum(row_phase(start:start+2));
                                
                                %Find difference of the means
                                %'mean' function in MATLAB is slow
                                seg_phase_diff = (next_start_mean-end_mean)/3;
                                
                                if abs(seg_phase_diff) > pi
                                    %Find next two points in signal
                                    next_two    = find(row_mask(prev_end+1:end),2);
                                    shift_start = next_two(2)+prev_end;
                                    row_phase(shift_start:end) = row_phase(shift_start:end) - round(seg_phase_diff/pi_2)*pi_2;
                                    
                                    aa = next_two(1)+prev_end;
                                    bb = next_two(2)+prev_end;
                                    
                                    inter_diff_l = row_phase(bb) - row_phase(aa);
                                    
                                    if abs(inter_diff_l) >= pi_2
                                        row_phase(bb) = row_phase(bb) - pi_2*fix(inter_diff_l/pi_2);
                                    end
                                    
                                end
                            end
                        end
                        prev_end = ii;
                    end
                end
                ii = ii+1;
            end
            
            if num_seg > 1 %Perhaps this should happen regardless.
                %Shift pixels before first segment
                if first_start > 1
                    index_sig  = find(row_mask(1:first_start-1));
                    start_seg   = row_phase(index_sig);
                    phase_diff = row_phase(first_start) - sum(start_seg, 'omitnan')/nnz(row_mask(1:first_start-1));
                    row_phase(index_sig) = start_seg + pi_2*round(phase_diff/pi_2);
                end
                
                %Shift pixels after last segment
                if prev_end ~= length(row_phase)
                    index_sig  = find(row_mask(prev_end+1:end));
                    end_seg     = phase_input(row,prev_end+index_sig);
                    phase_diff = row_phase(prev_end) - sum(end_seg, 'omitnan')/nnz(row_mask(prev_end+1:end));
                    row_phase(prev_end+index_sig) = end_seg + pi_2*round(phase_diff/pi_2);
                end
            end
            phase_out(row,:) = row_phase.*row_mask;
        end
    end
end