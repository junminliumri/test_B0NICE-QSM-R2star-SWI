% DEPULM_2D_DIFF_Y: Find and correct outliers
%
%   USAGE : [out_2D] = dePULM_2D_diff_y(phase_tmp)
%
%   INPUTS:
%       phase_input           - (m x n) array / phase image
%
%   OUTPUTS:
%       out_2D                - (m x n) array / phase image
%
%   NOTES:
%       First and last row are calculated on updated image, interior are
%       calculated on original.
%
%   SEE ALSO : DEPULM_2D_DIFF
function [out_2D] = dePULM_2D_diff_y(phase_tmp)
    out_2D = dePULM_2D_diff(phase_tmp');
    out_2D = out_2D';
end