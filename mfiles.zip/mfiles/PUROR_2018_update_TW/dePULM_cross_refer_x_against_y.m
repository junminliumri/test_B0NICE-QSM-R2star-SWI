% DEPULM_CROSS_REFER_X_AGAINST_Y: Cross refers an unwrapped phase image
%                                 with another phase image. Operates on
%                                 line segments with gradient under seg_phi
%
%   USAGE: [phase_out] = dePULM_cross_refer_x_against_y(reference_phase,phase_input,seg_phi,mask)
%
%   INPUTS:
%       reference_phase - (m x n) array / phase image used as reference
%       phase_input     - (m x n) array / phase image to shift
%       seg_phi         - maximum gradient of a line segment
%       mask            - (m x n) binary array of points to use
%
%   OUTPUTS:
%       phase_out - (m x n) array shifted to match high quality strip
%
%   SEE ALSO : DEPULM_CROSS_REFER_Y_AGAINST_X DEPULM_2D_QUALITY
function [phase_out] = dePULM_cross_refer_x_against_y(reference_phase, phase_input,seg_phi,mask)
    
    phase_out = dePULM_cross_refer_y_against_x(reference_phase', phase_input',seg_phi,mask');
    phase_out = phase_out';
end
