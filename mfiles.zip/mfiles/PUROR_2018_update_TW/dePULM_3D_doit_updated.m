% this program is for volunteer results acquired using 3D SPGR in GE 3T
% scanner
%
%
function [phase_tmp_ref, phase_tmp] = dePULM_3D_doit_updated(phase_tmp_ref,phase_tmp,mask_2D,mask_2D_h)
    
    [~, cell_connect_y] =  dePULM_2D_ini_xy_connect(mask_2D);
      
    [phase_ls_y] = dePULM_connect_line_segments_y(phase_tmp,mask_2D);
    [phase_tmp]= dePULM_unwrap_line_means_y(phase_ls_y, mask_2D, cell_connect_y);
    
    [~, xy_start_dw, xy_start_up] = dePULM_2D_quality(phase_tmp_ref, mask_2D_h);
    [phase_tmp] = dePULM_2D_xy_cen(phase_tmp_ref,phase_tmp,xy_start_dw,xy_start_up,mask_2D_h);
%     
    seg_phi = pi;
    for test_loop = 1:6
       [phase_tmp] = dePULM_cross_refer_y_against_x(phase_tmp_ref, phase_tmp,seg_phi,mask_2D);
       [phase_tmp_ref] = dePULM_cross_refer_x_against_y(phase_tmp, phase_tmp_ref,seg_phi,mask_2D);
        seg_phi = seg_phi/2;
    end   
    
    [phase_tmp] = dePULM_2D_diff_y(phase_tmp);
    %[phase_tmp_ref] = dePULM_2D_diff(phase_tmp_ref); NOT USED
end