% Unwrap rows and columns of phase image in alternating directions
%
%
%
function [phase_itoh_y, mask_2D] = dePULM_2D_itoh(phase_original,~)

    [nRows, nColumns] = size(phase_original);

    phase_itoh_y = zeros(nRows,nColumns);
    mask_2D = zeros(nRows,nColumns);
    
    phase_itoh_y(:,2:2:nColumns)          = unwrap(phase_original(:,2:2:nColumns), [], 1);            %unwrap even columns top to bottom
    phase_itoh_y(nRows:-1:1,1:2:nColumns) = unwrap(phase_original(nRows:-1:1,1:2:nColumns), [], 1);   %unwrap odd  columns bottom to top
    
    mask_2D(phase_original~=0)=1;        %Not convinced mask generation should be in here
    phase_itoh_y(phase_original==0)=0;   %Should be moved out to 3D loop?

end
