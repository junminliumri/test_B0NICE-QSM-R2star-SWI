% DEPULM_2D_DIFF: Find and correct outliers
%
%   USAGE : [out_2D] = dePULM_2D_diff(phase_tmp)
%
%   INPUTS:
%       phase_input           - (m x n) array / phase image
%
%   OUTPUTS:
%       out_2D                - (m x n) array / phase image
%
%   NOTES:
%       First and last row are calculated on updated image, interior are
%       calculated on original.
%
%   SEE ALSO : DEPULM_2D_DIFF_Y
function [out_2D] = dePULM_2D_diff(phase_input)
    
    pi_2 = pi*2.0;
    [nRows, nCols] = size(phase_input);
    
    %Find pixels with non-zeros above and below
    HQpointsX     = phase_input~=0;
    HQpointsX     = imerode(HQpointsX, [1;1;1]);
    
    %Find pairs of pixels with phase gradient above pi
    phase_diff      = diff(phase_input);
    phase_diff_mask = abs(phase_diff)>pi;
    
    for row = 2:(nRows - 1)
        
        index_x_b = find(HQpointsX(row, :));
        len_x_b   = length(index_x_b);
        
        q_up      = find(phase_diff_mask(row-1, index_x_b));
        q_dw      = find(phase_diff_mask(row, index_x_b));
        len_up    = length(q_up);
        len_dw    = length(q_dw);
        
        %If there are high gradients above and below find
        %intersection and correct (unless there are very few)
        if len_up && len_dw
            
            quality_up = (len_x_b - len_up)/len_x_b;
            quality_dw = (len_x_b - len_dw)/len_x_b;
            quality_br = quality_up*quality_dw;
            
            if quality_br < 0.95
                
                bad_up = zeros(1,nCols);
                bad_dw = zeros(1,nCols);
                
                bad_up(index_x_b(q_up)) = true;
                bad_dw(index_x_b(q_dw)) = true;
                bad_point = bad_up & bad_dw;
                fix_index = find(bad_point);
                
                if fix_index
                    
                    diff_up = phase_diff(row-1, fix_index);
                    diff_dw = phase_diff(row,   fix_index);
                    
                    shift_tmp = (diff_dw - diff_up);
                    shift_tmp = shift_tmp/2;
                    phase_input(row,fix_index) = phase_input(row,fix_index) + pi_2*(round(shift_tmp/pi_2));
                    
                end
                
            end
            
        end
        
    end
    
    %Redo for first/last in case it changed
    HQpointsX = phase_input([1,2,nRows-1,nRows],:)~=0;
    HQpointsX = imerode(HQpointsX, [1;1;1]);
    
    %index_y = 1;
    fix_index = find(HQpointsX(1, :));
    countFix  = length(fix_index);
    
    shift_tmp = phase_input(2,fix_index) - phase_input(1,fix_index);
    q_dw      = find(abs(shift_tmp) > pi);
    len_dw    = length(q_dw);
    
    if len_dw && countFix > 2
        
        quality_dw = (countFix - len_dw)/countFix;
        
        if quality_dw < 0.95
            phase_input(1,fix_index) = phase_input(1,fix_index) + pi_2*(round(shift_tmp/pi_2));
        end
        
    end
    
    %index_y = nRows;
    fix_index = find(HQpointsX(4, :));
    countFix  = length(fix_index);
    
    shift_tmp = phase_input(nRows-1,fix_index) - phase_input(nRows,fix_index);
    q_dw      = find(abs(shift_tmp) > pi);
    len_dw    = length(q_dw);
    
    if len_dw && countFix > 2
        
        quality_dw = (countFix - len_dw)/countFix;
        
        if quality_dw < 0.95
            phase_input(nRows,fix_index) = phase_input(nRows,fix_index) + pi_2*(round(shift_tmp/pi_2));
        end
        
    end
    
    out_2D = phase_input;
    
end
