% DEPULM_2D_XY_CEN: Shifts values of phase image to match values of high
%                   quality strip identified in reference image
%
%   USAGE: [phase_out] = dePULM_2D_xy_cen_y(reference_phase,phase_input,xy_start,xy_end,mask)
%
%   INPUTS:
%       reference_phase - (m x n) array / phase image used as reference
%       phase_input     - (m x n) array / phase image to shift
%       xy_start        - start of strip to use as reference
%       xy_end          - end of strip to use as reference
%       mask            - (m x n) binary array of points to use
%
%   OUTPUTS:
%       phase_out - (m x n) array shifted to match high quality strip
%
%   SEE ALSO : DEPULM_2D_XY_CEN DEPULM_2D_QUALITY_Y
function [out_2D] = dePULM_2D_xy_cen_y(phase_tmp_ref,phase_tmp,xy_start_dw,xy_start_up,mask)

    out_2D = dePULM_2D_xy_cen(phase_tmp_ref', phase_tmp', xy_start_dw, xy_start_up, mask');
    
    out_2D = out_2D';
    
end