
%
function [unwrapphase] = EchoPhaseUnwrapping(file4complexData, file4fm, flag_HP)
    load(file4complexData);
    load(file4fm);
    %
    fm(isnan(fm)) = 0;
    %
    algoParams.FieldStrength = imDataParams.FieldStrength;
    algoParams.TE_seq = imDataParams.TE;
    algoParams.matrix_size = size(imDataParams.images);
    %stop
    %
    TE = imDataParams.TE;
    matrix_size = size(imDataParams.images);
    pi_2 = 2*pi;
    %flag_HP = 1;
    if flag_HP == 1
        unwrapphase= zeros(matrix_size(1),matrix_size(2),matrix_size(3),matrix_size(5));
        for index_echo = 2:matrix_size(5)
        deltaTE = TE(index_echo)-TE(1);
        phase_B0(:,:,:) = 2*pi*fm*deltaTE; 
        %
        complex_HP(:,:,:) = imDataParams.images(:,:,:,1,index_echo).*conj(imDataParams.images(:,:,:,1,1));
        complex_B0cor(:,:,:) = complex_HP.*exp(-1i*phase_B0);
        %complex_B0cor(:,:,:) = complex_B0cor(:,:,:).*conj(complexFromFF(:,:,:,index_echo));
        %complex_HP = complex_HP.*conj(complexFromFF(:,:,:,index_echo));
        %
        %real_filt = imgaussfilt3(real(complex_B0cor),[3 3 3]);
        %imag_filt = imgaussfilt3(imag(complex_B0cor),[3 3 3]);
        %complex_B0cor = real_filt + 1i*imag_filt;clear real_filt; clear imag_filt;
        %
        unwrap_mode = 3;
        [algoParams] = FatCats_SetAlgoParams4IEV_PUROR(complex_B0cor, unwrap_mode);
        algoParams.complex4mask = squeeze(abs(imDataParams.images(:,:,:,1,2)));
        [algoParams] = FatCats_unwrapPhaseUsingPUROR(algoParams);
        %
        %[algoParams.unwrap_phase] = PUROR_check3D(complex_B0cor, algoParams.unwrap_phase);
        %figure(1);imshow3Dfull(algoParams.unwrap_phase,[-4*pi 4*pi]);
        %figure(2);imshow3Dfull(phs_final,[-4*pi 4*pi]);
        %
        algoParams.unwrap_phase = algoParams.unwrap_phase + phase_B0;
        phase_diff = angle(complex_HP)- algoParams.unwrap_phase;%phase_B0;    
        algoParams.unwrap_phase = angle(complex_HP) - pi_2*round(phase_diff./pi_2);
        %
        %phase_filt = imgaussfilt3(algoParams.unwrap_phase,[5 5 3]);
        %phase_diff = algoParams.unwrap_phase - phase_filt;
        %algoParams.unwrap_phase = algoParams.unwrap_phase - pi_2*round(phase_diff./pi_2);
        %
        %figure(1);imshow3Dfull(algoParams.unwrap_phase,[-4*pi 4*pi]);
        %index_echo
        %pause
        unwrapphase(:,:,:,index_echo) = algoParams.unwrap_phase;
        end
    else%
        unwrapphase = zeros(matrix_size(1),matrix_size(2),matrix_size(3),matrix_size(5));
        for index_echo = 1:matrix_size(5)
        deltaTE = TE(index_echo);
        phase_B0(:,:,:) = 2*pi*fm*deltaTE; 
        %
        complex_HP(:,:,:) = imDataParams.images(:,:,:,1,index_echo);
        complex_B0cor(:,:,:) = complex_HP.*exp(-1i*phase_B0);
        %complex_B0cor(:,:,:) = complex_B0cor(:,:,:).*conj(complexFromFF(:,:,:,index_echo));
        %complex_HP = complex_HP.*conj(complexFromFF(:,:,:,index_echo));
        %
        %real_filt = imgaussfilt3(real(complex_B0cor),[3 3 3]);
        %imag_filt = imgaussfilt3(imag(complex_B0cor),[3 3 3]);
        %complex_B0cor = real_filt + 1i*imag_filt;clear real_filt; clear imag_filt;
        %
        unwrap_mode = 3;
        [algoParams] = FatCats_SetAlgoParams4IEV_PUROR(complex_B0cor, unwrap_mode);
        algoParams.complex4mask = squeeze(abs(imDataParams.images(:,:,:,1,2)));
        [algoParams] = FatCats_unwrapPhaseUsingPUROR(algoParams);
        %
        algoParams.unwrap_phase = algoParams.unwrap_phase + phase_B0;
        phase_diff = angle(complex_HP)- algoParams.unwrap_phase;%phase_B0;    
        algoParams.unwrap_phase = angle(complex_HP) - pi_2*round(phase_diff./pi_2);
        %
        unwrapphase(:,:,:,index_echo) = algoParams.unwrap_phase;
        end
    
    end%
    %save('unwrap_raw_3D.mat','unwrapphase');
    


