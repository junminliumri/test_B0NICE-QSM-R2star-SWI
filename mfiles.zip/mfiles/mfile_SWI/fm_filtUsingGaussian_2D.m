function [fm_LowPassed] = fm_filtUsingGaussian_2D(fm,sigma,RESx, RESy,RESz,IEV_debug)
% filtering the unwrapped image
matrix_size = size(fm);
if length(matrix_size) == 2
matrix_size(3) = 1;
end
    %
    [fm_LowPassed] = LowPassed_FourierFilter_2D(fm, sigma, RESx, RESy,RESz);
    %
        if IEV_debug == 10
        for index_slice = 1:matrix_size(3)
            
            subplot(1,2,1);imagesc(fm_LowPassed(:,:,index_slice),[-100 100]);colormap gray;axis square;axis off;
            subplot(1,2,2);imagesc(fm(:,:,index_slice),[-100 100]);colormap gray;axis square;axis off;
            index_slice
            pause
        end
        end
end
%
%
function [PU_lowsf] = LowPassed_FourierFilter_2D(PU, sigma,RESx, RESy,RESz)
%This function produces a background-filtered phase map using the unwrapped phase data

%Get the relevant matrix size and create new arrays
[m,n,ns] = size(PU);
PUfilt = zeros(size(PU));
PU_lowsf = zeros(size(PU));
%The FWHM of a gaussian filter is given by sigma*(2*sqrt(2*log(2)))
FWHMfilter = sigma*(2*sqrt(2*log(2)));
%Define whether the acquisition is 2D or 3D
ndims = 3;
%Get the number of echoes
ne = 1;

if ndims == 2
     
    %Make the 2D Gaussian filter ...sigma = 0.004 (less severe filtering) - 0.015 (more severe filtering) 
    x2 = reshape((((0:m-1) - floor(m/2)).*(RESx)).^2, [m 1]);
    y2 = reshape((((0:n-1) - floor(n/2)).*(RESy)).^2, [1 n]);
    F = x2(:,ones(n,1)) + y2(ones(m,1),:);
    F = exp(-F./(2*sigma.^2));
    %F = F./sum(F(:));
    F = ifftshift(F);
    %
        for ss = 1:ns

            %Filter in the frequency domain:
            PU_lowsf(:,:,ss) = fftshift(ifftn(F.*fftn(ifftshift(PU(:,:,ss)))));

        end    
    %
 
elseif ndims == 3
    
    % Make the 3D Gaussian filter ..sigma = 0.004 (less severe filtering) - 0.015 (more severe filtering) 
    x2 = reshape((((0:m-1) - floor(m/2)).*(RESx)).^2, [m 1 1]);
    y2 = reshape((((0:n-1) - floor(n/2)).*(RESy)).^2, [1 n 1]);
    z2 = reshape((((0:ns-1) - floor(ns/2)).*(RESz)).^2, [1 1 ns]);
    F = x2(:,ones(n,1), ones(ns,1)) + y2(ones(m,1),:,ones(ns,1)) + z2(ones(m,1),ones(n,1),:);
    F = exp(-F./(2*sigma.^2));
    %F = F./sum(F(:));
    F = ifftshift(F);
    clear x2 y2 z2

    %Apply the 3D Gaussian filter across echoes:
    for ee = 1:ne

        %Filter in the k-pace domain:
        PU_lowsf(:,:,:,ee) = fftshift(ifftn(F.*fftn(ifftshift(PU(:,:,:,ee)))));

    end


    %The high spatial frequency phase data is what we're interested in.
    PUfilt = PU - PU_lowsf; 

    %Add the diamagnetic convention to the data:
    PUfilt = -PUfilt;

    %The FWHM of a gaussian filter is given by sigma*(2*sqrt(2*log(2)))
    FWHMfilter = sigma*(2*sqrt(2*log(2)));
    
else
end
%
end
