function [SWI, Phase_filt, PhaseMask] = SWI_echoBYecho(file4complexData, file4unwrapped)
m = 4;
load(file4complexData);
load(file4unwrapped);
mag = squeeze(abs(imDataParams.images));
TE = imDataParams.TE;
clear imdataParams;

for index_echo = 2:size(unwrapphase,4)
    [fm_LowPassed] = fm_filtUsingGaussian_2D(unwrapphase(:,:,:,index_echo),0.006,0.001, 0.001,0.002,0);
    Phase_filt(:,:,:,index_echo) = (unwrapphase(:,:,:,index_echo) - fm_LowPassed).*(TE(index_echo)/(TE(index_echo)-TE(1)));
end
%
Phase_filt = -Phase_filt;
%
PhaseMask = (Phase_filt + pi)./pi;
PhaseMask(PhaseMask > 1) = 1;
PhaseMask(PhaseMask <0) = 0;
PhaseMask = PhaseMask.^m;
%

for index_echo = 2:size(PhaseMask,4)
    tmp(:,:,:) = mag(:,:,:,index_echo).*PhaseMask(:,:,:,index_echo);
    SWI(:,:,:,index_echo) = tmp;%BSplineInterpolation(tmp,[1 1 2]);
    %imshow3Dfull(BSplineInterpolation(SWI(:,:,:,index_echo),[2 2 2]));colormap gray;
    %index_echo
    %pause
end
%
%save SWI_gaussianFILT_006.mat SWI Phase_filt PhaseMask;
%

